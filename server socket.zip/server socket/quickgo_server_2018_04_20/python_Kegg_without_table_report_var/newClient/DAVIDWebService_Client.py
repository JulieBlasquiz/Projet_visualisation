import sys
sys.path.append('../') 
import logging                       # S'identifier pour l API DAVID
import traceback as tb               # Essentiel pour API DAVID
import suds.metrics as metrics       # Essentiel pour API DAVID
from tests import *                  # Essentiel pour API DAVID
from suds import *                   # Essentiel pour API DAVID
from suds.client import Client       # Essentiel pour API DAVID
from datetime import datetime        # Essentiel pour API DAVID
from collections import Counter      # Compter le nombre de fois ou un meme element est present 
from operator import itemgetter      # Permet de trier
from collections import OrderedDict  # Ordonner dictionnaires

#Connexion David :
def connexion_DAVID():
    errors = 0
    setup_logging()
    logging.getLogger('suds.client').setLevel(logging.DEBUG)
    url = 'https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'
    
    # create a service client using the wsdl.
    client = Client(url)
    client.wsdl.services[0].setlocation('https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

    #authenticate user email 
    client.service.authenticate('reviewer@reviewer.org')
    setup_logging()
    logging.getLogger('suds.client').setLevel(logging.DEBUG)
    url = 'https://david.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'

    # create a service client using the wsdl.
    client = Client(url)
    client.wsdl.services[0].setlocation('https://david.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

    #authenticate user email
    client.service.authenticate('julie.blasquiz@etu.u-bordeaux.fr')
    #print "DAVID connexion established\n"         
    return client

def create_result_file(): 
    #Creation des listes, dictionnaires ou seront stocke les donnees
    #liste_fichier_entree = ['listiduniprot1.txt','listiduniprot2.txt']
    liste_ID, liste_annot1, liste_annot2, liste_geneID1, liste_geneID2 = [],[],[],[],[]
    liste_liste_annot = [liste_annot1,liste_annot2]
    liste_liste_geneID = [liste_geneID1,liste_geneID2]
    liste_value = []
    dico_yep1,dico_yep2,dico_nb_annot1,dico_nb_annot2 = {},{},{},{}
    dico_index_annot1,dico_index_annot2 = {},{}
    liste_dico = [dico_index_annot1,dico_index_annot2]
    liste_dico_nbannot = [dico_nb_annot1,dico_nb_annot2]
    liste_dico_yep = [dico_yep1,dico_yep2]

    #Lire les 2 fichiers d entree => listes des ID des 2 groupes
    lines = sys.stdin.readlines()
    #print lines[0]
    #lines = json.loads(lines[0])
    lines = lines[0].split(";")
    print lines[0]
    print lines[1]
    for i in range(2):
        #with open(liste_fichier_entree[i], 'r') as fichier :
        #    inputIds = fichier.read()
        inputIds = lines[i]
        #API DAVID : Obtention des annotations correspondant aux ID
        idType,listName,listType = 'UNIPROT_ACCESSION','make_up',0
        #print client.service.addList(inputIds, idType, listName, listType)

        categorySting = str(client.service.setCategories('KEGG_PATHWAY'))
        categories = categorySting.split(',')

        tableReport = client.service.getTableReport()
        tableRow = len(tableReport)

	for tableRecord in tableReport:
            name = tableRecord.name
	    name = name.replace(",",";")
	    for arrayString in tableRecord.values:
		gene_id = ','.join(x for x in arrayString.array)
	        liste_ID.append(gene_id)
	    for annotationRecord in tableRecord.annotationRecords:
	    	default_value = ''
		category_dict = dict.fromkeys(categories,default_value)
		termsConcat = '';
		for term in annotationRecord.terms:
		    termString = term.split(":")[1]
	            termString = termString.replace(",","")
		    geneidname = gene_id+' : '+ name
		    liste_liste_annot[i].append(termString)
		    liste_liste_geneID[i].append(geneidname)
	print "coucou"
        #Traitement des donnees obtenues de l'API
	gene_liste = liste_liste_geneID[i]        

        for annotation in set(liste_liste_annot[i]):
    	    for j,annot in enumerate(liste_liste_annot[i]):
                if annot == annotation:
		    liste_dico[i].setdefault(annot, set()).add(j)

        for cle,value in liste_dico[i].iteritems():
	    for v in value:
	        id_gene = gene_liste[v]
		liste_value.append(id_gene)
    		liste_value = list(set(liste_value))
            liste_dico_nbannot[i][cle] = len(liste_value)
	    var = '_ '.join(j for j in liste_value)
	    liste_dico_yep[i][cle] = var
	    liste_value = []
	    var = None

    tot_total = len(liste_annot1) + len(liste_annot2)

    dico_annot_commune1,dico_annot_id1 = {},{}
    liste_id_commun = []
    dico_nb_idcommun,dico_idcommun = {},{}
    var2 = None
    dico_annot_commune2,dico_annot_id2 = {},{}
    
    for i in range(len(dico_yep1)):
        if dico_yep1.keys()[i] in dico_yep2.keys():
            dico_annot_commune1[dico_yep1.keys()[i]] = dico_nb_annot1.values()[i]
            dico_annot_id1[dico_yep1.keys()[i]] = dico_yep1.values()[i]

    for i in range(len(dico_yep2)):
        if dico_yep2.keys()[i] in dico_yep1.keys():
            dico_annot_commune2[dico_yep2.keys()[i]] = dico_nb_annot2.values()[i]
            dico_annot_id2[dico_yep2.keys()[i]] = dico_yep2.values()[i]

    for annotation in dico_annot_commune2:
        for annot in dico_annot_commune1.keys():
            if annot == annotation:
		liste_temp1 = dico_annot_id1[annot].split('_ ')		
		liste_temp2 = dico_annot_id2[annot].split('_ ')
		liste_temp1 = list(set(liste_temp1))
		liste_temp2 = list(set(liste_temp2))
		for i in range(len(liste_temp1)):
		    if liste_temp1[i] in liste_temp2:
			liste_id_commun.append(liste_temp1[i])
			var2 = ' '.join(j for j in liste_id_commun)
			dico_nb_idcommun[annot] = len(liste_id_commun)
		        dico_idcommun[annot] = var2
		liste_id_commun = []
		var2 = None

    #Trier les dicos en fonction de leur cle (annotations) par ordre alphabetique
    dico_annot_commune1 = OrderedDict(sorted(dico_annot_commune1.items(), key=lambda t: t[0]))
    dico_annot_commune2 = OrderedDict(sorted(dico_annot_commune2.items(), key=lambda t: t[0]))
    dico_idcommun = OrderedDict(sorted(dico_idcommun.items(), key=lambda t: t[0]))
    dico_annot_id1 = OrderedDict(sorted(dico_annot_id1.items(), key=lambda t: t[0]))
    dico_annot_id2 = OrderedDict(sorted(dico_annot_id2.items(), key=lambda t: t[0]))
    dico_nb_annot1 = OrderedDict(sorted(dico_nb_annot1.items(), key=lambda t: t[0]))
    dico_nb_annot2 = OrderedDict(sorted(dico_nb_annot2.items(), key=lambda t: t[0]))
    dico_yep1 = OrderedDict(sorted(dico_yep1.items(), key=lambda t: t[0]))
    dico_yep2 = OrderedDict(sorted(dico_yep2.items(), key=lambda t: t[0]))

    #Ecrire les donnees dans le fichier result.txt
    #with open('result.txt', 'w') as f :
	#Ecrire sur une ligne : Annotation, le nombre d'ID implique pour cette annot dans le groupe1, le groupe commun, le groupe2, le nombre d'annot total, les genes impliques du groupe1, du groupe commun, du groupe2
    result = 'Annot'+','+'1'+','+'2'+','+'3'+','+'N'+','+'geneID1'+','+'geneIDCommon'+','+'geneID2'
    for annot in dico_annot_commune1.keys():
	if annot in dico_idcommun.keys():
            result = result + '\n'+str(annot)+','+str(dico_annot_commune1[annot])+','+str(dico_nb_idcommun[annot])+','+str(dico_annot_commune2[annot])+','+str(tot_total)+','+str(dico_annot_id1[annot])+','+str(dico_idcommun[annot])+','+str(dico_annot_id2[annot])
	else :
	    result = result + '\n'+str(annot)+','+str(dico_annot_commune1[annot])+','+'0'+','+str(dico_annot_commune2[annot])+','+str(tot_total)+','+str(dico_annot_id1[annot])+','+''+','+str(dico_annot_id2[annot])
    for i in range(len(dico_nb_annot1.keys())):
        if dico_nb_annot1.keys()[i] not in liste_annot2:
	    result = result + '\n'+str(dico_nb_annot1.keys()[i])+','+str(dico_nb_annot1.values()[i])+','+'0'+','+'0'+','+str(tot_total)+','+str(dico_yep1.values()[i])+','+""+','+""
    for i in range(len(dico_nb_annot2.keys())):
        if dico_nb_annot2.keys()[i] not in liste_annot1:
	    result = result + '\n'+str(dico_nb_annot2.keys()[i])+','+'0'+','+'0'+','+str(dico_nb_annot2.values()[i])+','+str(tot_total)+','+""+','+""+','+str(dico_yep2.values()[i])
    return liste_ID, result

#Show the ID with no annotation matched :
def no_match_ID():
    ID_init, ID_lost = [],[]
    liste_fichier_entree = ['listiduniprot1.txt','listiduniprot2.txt']
    for i in range(len(liste_fichier_entree)):
        with open(liste_fichier_entree[i],'r') as fichier:
            for ligne in fichier:
	        ligne = ligne.strip(',\n')
	        ID_init.append(ligne)
    with open('No_match.txt', 'w') as f :
        for ID in ID_init:
            if ID not in ID_trouves:
	        f.write(str(ID)+','+'\n')

#Fonction call :
if __name__ == '__main__':
    client = connexion_DAVID()
    ID_trouves = create_result_file()[0]
    result = create_result_file()[1]
    print result
    #no_match_ID()
