#import ssl
#ssl._create_default_https_context = ssl._create_unverified_context

import sys
sys.path.append('../')

import logging
import traceback as tb
import suds.metrics as metrics
from tests import *
from suds import *
from suds.client import Client
from datetime import datetime
from collections import Counter
from operator import itemgetter
from collections import OrderedDict

errors = 0

setup_logging()

logging.getLogger('suds.client').setLevel(logging.DEBUG)

url = 'https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'
    
print 'url=%s' % url

# create a service client using the wsdl.
client = Client(url)
client.wsdl.services[0].setlocation('https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

#authenticate user email 
client.service.authenticate('reviewer@reviewer.org')

#add a list
fichier = open('listiduniprot1.txt','r')
ListeID = fichier.read()
fichier.close()

inputIds = ListeID
idType = 'UNIPROT_ACCESSION'
listName = 'make_up'
listType = 0

print client.service.addList(inputIds, idType, listName, listType)
print client.service.getDefaultCategoryNames()

errors = 0

setup_logging()

logging.getLogger('suds.client').setLevel(logging.DEBUG)

url = 'https://david.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'

# create a service client using the wsdl.
client = Client(url)
client.wsdl.services[0].setlocation('https://david.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

#authenticate user email
client.service.authenticate('julie.blasquiz@etu.u-bordeaux.fr')

#add a list
liste_fichier_entree = ['listiduniprot1.txt','listiduniprot2.txt']
liste_fichier_sortie = ['list.tableReport1.txt','list.tableReport2.txt']

for i in range(len(liste_fichier_entree)):
    fichier = open(liste_fichier_entree[i],'r')
    ListeID = fichier.read()
    fichier.close()

    inputIds = ListeID
    idType = 'UNIPROT_ACCESSION'
    listName = 'make_up'
    listType = 0
    print client.service.addList(inputIds, idType, listName, listType)

    categorySting = str(client.service.setCategories('KEGG_PATHWAY'))
    categories=categorySting.split(',')

    tableReport = client.service.getTableReport()
    tableRow = len(tableReport)
    print 'Total table records:',tableRow

    with open(liste_fichier_sortie[i], 'w') as fOut:
	    liste_Annot = []
	    for tableRecord in tableReport:
                name = tableRecord.name
	        name = name.replace(",",";")
	        for arrayString in tableRecord.values:
		    gene_id = ','.join(x for x in arrayString.array)
	        for annotationRecord in tableRecord.annotationRecords:
	    	    default_value = ''
		    category_dict = dict.fromkeys(categories,default_value)
		    termsConcat = '';
		    for term in annotationRecord.terms:
		        termString = term.split(":")[1]
			termString = termString.replace(",","")
		        liste_Annot.append(termString)
		        liste_Annot = list(set(liste_Annot))
		    for annot in liste_Annot:
			    fOut.write(str(annot)+','+str(gene_id)+' : '+str(name)+','+'\n')

# Script permettant de parser le fichier de sortie de David :
liste_annot = []
liste_id = []
dico_index_annot = {}
dico_yep = {}
liste_value = []
dico_nb_annot = {}

liste_fichier_entree = ['list.tableReport1.txt','list.tableReport2.txt']

for a in range(2):
    with open(liste_fichier_entree[a], 'r') as f :
	tot_annot = 0
        for line in f :
            liste_annot.append(line.split(',')[0])
            liste_id.append(line.split(',')[1])
            tot_annot = tot_annot + 1

        for annotation in set(liste_annot):
    	    for i,annot in enumerate(liste_annot):
		    if annot == annotation:
			    dico_index_annot.setdefault(annot, set()).add(i)

        for cle,value in dico_index_annot.iteritems():
	    for v in value:
		    id_gene = liste_id[v]
		    liste_value.append(id_gene)
		    liste_value = list(set(liste_value))
	    dico_nb_annot[cle] = len(liste_value)
	    var = '_ '.join(j for j in liste_value)
	    dico_yep[cle] = var
	    liste_value = []
	    var = None

    with open(liste_fichier_entree[a], 'w') as f :
        for j in range(len(dico_yep)):
            f.write(str(dico_yep.keys()[j])+','+str(dico_nb_annot.values()[j])+','+'0'+','+'0'+','+str(tot_annot)+','+str(dico_yep.values()[j])+'\n')

liste_annot1 = []
liste_id1 = []
liste_nb_annot1 = []
dico_annot_commune1 = {}
dico_annot_id1 = {}

liste_id_commun = []
dico_nb_idcommun = {}
dico_idcommun = {}
var2 = None

liste_annot2 = []
liste_id2 = []
liste_nb_annot2 = []
dico_annot_commune2 = {}
dico_annot_id2 = {}

with open('list.tableReport1.txt', 'r') as f :
    for line in f :
        liste_annot1.append(line.split(',')[0])
	liste_nb_annot1.append(line.split(',')[1])
        liste_id1.append(line.split(',')[5])
    tot_annot1 = line.split(',')[4]

with open('list.tableReport2.txt', 'r') as f :
    for line in f :
        liste_annot2.append(line.split(',')[0])
	liste_nb_annot2.append(line.split(',')[1])
        liste_id2.append(line.split(',')[5])
    tot_annot2 = line.split(',')[4]

tot_total = int(tot_annot1) + int(tot_annot2)

for i in range(len(liste_annot1)):
    if liste_annot1[i] in liste_annot2:
        dico_annot_commune1[liste_annot1[i]] = liste_nb_annot1[i]
        dico_annot_id1[liste_annot1[i]] = liste_id1[i].strip("\n")

for i in range(len(liste_annot2)):
    if liste_annot2[i] in liste_annot1:
        dico_annot_commune2[liste_annot2[i]] = liste_nb_annot2[i]
        dico_annot_id2[liste_annot2[i]] = liste_id2[i].strip("\n")

for annotation in dico_annot_commune2:
        for annot in dico_annot_commune1.keys():
            if annot == annotation:
		liste_temp1 = dico_annot_id1[annot].split('_ ')		
		liste_temp2 = dico_annot_id2[annot].split('_ ')
		liste_temp1 = list(set(liste_temp1))
		liste_temp2 = list(set(liste_temp2))
		for i in range(len(liste_temp1)):
		    if liste_temp1[i] in liste_temp2:
			liste_id_commun.append(liste_temp1[i])
			var2 = ' '.join(j for j in liste_id_commun)
			dico_nb_idcommun[annot] = len(liste_id_commun)
		        dico_idcommun[annot] = var2
		liste_id_commun = []
		var2 = None

dico_annot_commune1 = OrderedDict(sorted(dico_annot_commune1.items(), key=lambda t: t[0]))
dico_annot_commune2 = OrderedDict(sorted(dico_annot_commune2.items(), key=lambda t: t[0]))
dico_idcommun = OrderedDict(sorted(dico_idcommun.items(), key=lambda t: t[0]))
dico_annot_id1 = OrderedDict(sorted(dico_annot_id1.items(), key=lambda t: t[0]))
dico_annot_id2 = OrderedDict(sorted(dico_annot_id2.items(), key=lambda t: t[0]))

with open('result.txt', 'w') as f :
    f.write('Annot'+','+'1'+','+'2'+','+'3'+','+'N'+','+'geneID1'+','+'geneIDCommon'+','+'geneID2')
    for annot in dico_annot_commune1.keys():
        f.write('\n'+str(annot)+','+str(dico_annot_commune1[annot])+','+str(dico_nb_idcommun[annot])+','+str(dico_annot_commune2[annot])+','+str(tot_total)+','+str(dico_annot_id1[annot])+','+str(dico_idcommun[annot])+','+str(dico_annot_id2[annot]))

    for i in range(len(liste_annot1)):
        if liste_annot1[i] not in liste_annot2:
	    f.write('\n'+str(liste_annot1[i])+','+str(liste_nb_annot1[i])+','+'0'+','+'0'+','+str(tot_total)+','+str(liste_id1[i].strip("\n"))+','+""+','+"")

    for i in range(len(liste_annot2)):
        if liste_annot2[i] not in liste_annot1:
	    f.write('\n'+str(liste_annot2[i])+','+'0'+','+'0'+','+str(liste_nb_annot2[i])+','+str(tot_total)+','+""+','+""+','+str(liste_id2[i].strip("\n")))
