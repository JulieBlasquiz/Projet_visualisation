import sys
sys.path.append('../')
import logging
import traceback as tb
import suds.metrics as metrics
from tests import *
from suds import *
from suds.client import Client
from datetime import datetime
from collections import Counter
from operator import itemgetter
from collections import OrderedDict

#Connexion David :
def connexion_DAVID():
    errors = 0
    setup_logging()
    logging.getLogger('suds.client').setLevel(logging.DEBUG)
    url = 'https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'
    
    # create a service client using the wsdl.
    client = Client(url)
    client.wsdl.services[0].setlocation('https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

    #authenticate user email 
    client.service.authenticate('reviewer@reviewer.org')
    setup_logging()
    logging.getLogger('suds.client').setLevel(logging.DEBUG)
    url = 'https://david.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'

    # create a service client using the wsdl.
    client = Client(url)
    client.wsdl.services[0].setlocation('https://david.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

    #authenticate user email
    client.service.authenticate('julie.blasquiz@etu.u-bordeaux.fr')
    return client

#Create 2 tableReport files  :
def create_tableReports():
    liste_fichier_entree = ['listiduniprot1.txt','listiduniprot2.txt']
    liste_fichier_sortie = ['list.tableReport1.txt','list.tableReport2.txt']
    liste_ID = []
    for i in range(len(liste_fichier_entree)):
	with open(liste_fichier_entree[i],'r') as fichier:
            inputIds = fichier.read() 
        idType,listName,listType = 'UNIPROT_ACCESSION','make_up',0
        print client.service.addList(inputIds, idType, listName, listType)

        categorySting = str(client.service.setCategories('KEGG_PATHWAY'))
        categories=categorySting.split(',')

        tableReport = client.service.getTableReport()
        tableRow = len(tableReport)
        print 'Total table records:',tableRow

	with open(liste_fichier_sortie[i], 'w') as fOut:
	        liste_Annot = []
	        for tableRecord in tableReport:
                    name = tableRecord.name
	            name = name.replace(",",";")
	            for arrayString in tableRecord.values:
		        gene_id = ','.join(x for x in arrayString.array)
			liste_ID.append(gene_id)
	            for annotationRecord in tableRecord.annotationRecords:
	    	        default_value = ''
		        category_dict = dict.fromkeys(categories,default_value)
		        termsConcat = '';
		        for term in annotationRecord.terms:
		            termString = term.split(":")[1]
			    termString = termString.replace(",","")
		            liste_Annot.append(termString)
		            liste_Annot = list(set(liste_Annot))
		        for annot in liste_Annot:
			        fOut.write(str(annot)+','+str(gene_id)+' : '+str(name)+','+'\n')
    return liste_ID

#Fonction call :
client  = connexion_DAVID()
print "DAVID connexion established\n"
ID_trouves = create_tableReports()

def no_match_ID():
    ID_init, ID_lost = [],[]
    liste_fichier_entree = ['listiduniprot1.txt','listiduniprot2.txt']
    liste_fichier_sortie = 'result.txt'
    for i in range(len(liste_fichier_entree)):
        with open(liste_fichier_entree[i],'r') as fichier:
            for ligne in fichier:
	        ligne = ligne.strip(',\n')
	        ID_init.append(ligne)
    for ID in ID_init:
        if ID not in ID_trouves:
	    ID_lost.append(ID)
    return ID_lost

snif = no_match_ID()
print snif
