/**
BLASQUIZ Julie
LUCK Romain
MONGY Marc
RAFFAELLI Michele
14/05/2018
*/


//	--------------- Initialize data ---------------
var socket = io.connect('http://localhost:8082');
var dictGO = new Map();//GO annot as key and name of annot as value
var dictGOhist = new Map();
var tablevenn = [];

//receive input data
var dataimport1 = 0;
var dataimport2 = 0;

//	--------------- Event functions ---------------
//test button
var testeu = d3.select('#testeur').on('click',function(){
	alert(dataimport1);
});

//Uses show/hide buttons
var hidef1 = function() {hide("importtest");}
var hidef2 = function() {hide("back_hider");}
var hidef3 = function() {hide("venn_1");}
var hidef4 = function() {hide("listGO");}

//send data to quickGO
function launchbackGOf() {
	var genes1 = dataimport1;
	var genes2 = dataimport2;
	if (genes1.length == 0){alert("Error: group 1 is empty");}
	else if (genes2.length == 0){alert("Error: group 2 is empty");}
	else{sendquickgo(genes1,genes2);}
}

//open the input files
var openFile = function(event) {
	var input = event.target;
	var reader = new FileReader();
	reader.onload = function(){
		var text = reader.result;
		dataimport1 = text.split(",");
		}
	reader.readAsText(input.files[0]);
};
var openFile2 = function(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var text = reader.result;
        dataimport2 = text.split(",");
        }
    reader.readAsText(input.files[0]);
};
var openFile4 = function(event) {
	var input = event.target;
	var reader = new FileReader();
	reader.onload = function(){
		GOlist = reader.result;
		dictGO.forEach(function(value, key, map){dictGO.delete(key);});
		parseGO(GOlist);
		d3.selectAll(".GOnavbox").remove();
		d3.selectAll(".GOlabels").remove();
		appendGOlist();
		}
	reader.readAsText(input.files[0]);
};


//launch functions from html elements
var setupListeners = function() {
	launchbackGO.addEventListener('click', launchbackGOf);
	hide2.addEventListener('click',hidef2);
	hide4.addEventListener('click',hidef4);
	input1.addEventListener('change',openFile);
	input2.addEventListener('change',openFile2);
	input4.addEventListener('change',openFile4);
}


//	--------------- Non event functions ---------------
function loadServerFile(filePath) {
	var result = null;
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.open("GET", filePath, false);
	xmlhttp.send();
	if (xmlhttp.status==200) {
		result = xmlhttp.responseText;
	}
	return result;
}

//Hide or show a block in html
var hide = function(id){
	var x = document.getElementById(id);
	if (x.style.display === "none") {
		x.style.display = "block";
	}
	else {
		x.style.display = "none";
}}


//push first element of array to the end
var pushleft = function(tab){
	var tmp = tab[0];
	tab.splice(0,1);
	tab.push(tmp);
}

//delarray removes all duplicated elements - source: https://www.unicoda.com/?p=579
var delarray = function(array) {
    var len = array.length;
    var out = [];
    var obj = {};
    for (var i = 0; i < len; i++) {
	obj[array[i]] = 0;
    }
    var j;
    for (j in obj) {
	out.push(j);
    }
    return out;
}


//Parse the file data when uploading
var parsedata = function(text){
	var dataimport = text.split([","]);
	return dataimport;
}


function extractingFromJSONstring(groupe, body){
	var result = "";
	var object = JSON.parse(body);
	var genes = object.results;
	for(var geneIndex = 0; geneIndex<genes.length; geneIndex++){
		var gene = genes[geneIndex];
		var UniProtID = gene.geneProductId;
		var slimmedGO = gene.slimmedIds[0];
		result = result + '{"Liste":'+groupe+',"UniProtID":"'+UniProtID+'","SlimmedGO":"'+slimmedGO+'"},';
	}
	return result;
}

function parsingJSON(rawData,N){
	var data = JSON.parse(rawData);
	var listeGenesOntologiesPairs = [];
	var nombreElementsGroupe1 = 0;
	var nombreElementsGroupe2 = 0;
	for(var i = 0; i<data.length; i++){
	if(data[i].Liste == 1){
		nombreElementsGroupe1++;
	}
	if(data[i].Liste == 2){
		nombreElementsGroupe2++;
	}
	}
	var listeGO = [];
	for(var i = 0; i<data.length; i++){
		listeGO.push(data[i].SlimmedGO);
	}
	var uniqueListeGO = delarray(listeGO);
	var JSONstring = "[";
	var jsonElement;
	for(var j = 0; j<uniqueListeGO.length; j++){
		var uniprotGroupe1 = [];
		var uniprotGroupe2 = [];
		for(var i = 0; i<data.length; i++){
			if(data[i].SlimmedGO == uniqueListeGO[j] && data[i].Liste == 1){
				uniprotGroupe1.push('" '+data[i].UniProtID+'"');
				}
				if(data[i].SlimmedGO == uniqueListeGO[j] && data[i].Liste == 2){
				uniprotGroupe2.push('" '+data[i].UniProtID+'"');
			}
		}
		var uniqueUniprotGroupe1 = delarray(uniprotGroupe1);
		var uniqueUniprotGroupe2 = delarray(uniprotGroupe2);
		var uniqueUniprotGroupe3 = [];
		for(var i=0; i<uniqueUniprotGroupe1.length; i++){
			for(var k=0; k<uniqueUniprotGroupe2.length; k++){
				if(uniqueUniprotGroupe1[i] === uniqueUniprotGroupe2[k]){
					uniqueUniprotGroupe3.push(uniqueUniprotGroupe1[i]);
					break;
			}}}
		JSONstring = JSONstring+'{"Annot":"'+uniqueListeGO[j]+'","1":'+uniqueUniprotGroupe1.length+',"2":'+uniqueUniprotGroupe3.length+',"3":'+uniqueUniprotGroupe2.length+',"N":'+N+',"geneID1":['+uniqueUniprotGroupe1+'],"geneIDCommon":['+uniqueUniprotGroupe3+'],"geneID2":['+uniqueUniprotGroupe2+']},';
		}
	JSONstring = JSONstring.substr(0, JSONstring.length - 1)+ ']';
	return JSONstring;
}

//parse string data as json
var strtojson = function(databack){
var databacktmp = [];
for (var i=1; i<databack.length; i++){
	var dictmp = {};
	for (var j=0; j<databack[i].length; j++){
		dictmp[databack[0][j]]=databack[i][j];
	}
	databacktmp.push(dictmp);
}
return databacktmp;
}

var parseGO = function(GOannot){
	var splitGO = GOannot.split('\n');
	for(var i=0; i<splitGO.length; i++){
		var keyelem = splitGO[i].split(',');
		dictGO.set(keyelem[0],keyelem[1]);
	}
}


var preparesend = function(grp1, grp2, database){
	var datasend = database+";";
	for (var j=0; j<grp1.length; j++){
		datasend+= grp1[j]+',';
	}
	datasend+=";";
	for (var j=0; j<grp2.length; j++){
		datasend+= grp2[j]+",";
	}
	return datasend;
}

var sendquickgo = function(grp1,grp2){
	d3.select("#backblock").style("display","block");
	d3.select('#d3-plot').remove();
	d3.select("#loading").text('The process may take several minutes before data are returned : ');
	d3.select("#error1").text('');
	d3.select("#error2").text('');
	d3.select("#loading").append("img").attr("src",'images/ajax-loader.gif').attr('id',"Logo").attr('align','center');
	var datasend = preparesend(grp1, grp2, "quickGO");
	var GOlist = prepareGOlist();
	dictGOhist = dictGO;
	datasend+=";"+GOlist;
	socket.emit("message", datasend);
}

socket.on('message', function(message) {
	if("quickGOdata" == "quickGOdata"){
		d3.select("#loading").text('');
		d3.select('#Logo').remove();
		if(message.substring(0,6) == "Error "){
			d3.select('#error1').text(message);
		}
		else{
			var tmptab=message.split("  ");
			var databack1 = tmptab[0];
			var N1 = databack1.split(':');
			N1 = N1[1].split(',').length;
			var databack2 = tmptab[1];
			var N2 = databack2.split(':');
			N2 = N2[1].split(',').length;
			var N=N1+N2
			databack1 = extractingFromJSONstring(1,databack1);
			if(databack1.substring(28,30) == "[]"){
				d3.select('#error1').text("No result for group 1");
			}
			databack2 = extractingFromJSONstring(2,databack2);
			if(databack2.substring(28,30) == "[]"){
				d3.select('#error2').text("No result for group 2");
			}
			if(databack1.substring(28,30) !== "[]" && databack2.substring(28,30) !== "[]"){
				var databack = "["+databack1+databack2;
				databack = databack.substring(0,databack.length-1);
				databack+="]";
				databack = parsingJSON(databack,N);
				databack=JSON.parse(databack);
				backdiagram(databack);
			}
		}
	}
});

var backdiagram = function(data){
	var margin = {top: 50, right: 50, bottom: 10, left: 400},
	    width = 950 - margin.left - margin.right,
	    height = 50*data.length;

	var y = d3.scale.ordinal()
	    .rangeRoundBands([0, height], .3);

	var x = d3.scale.linear()
	    .rangeRound([0, width]);

	var color = d3.scale.ordinal()
	    .range(["#c7001e", "#cccccc", "#92c6db"]);

	var xAxis = d3.svg.axis()
	    .scale(x)
	    .orient("top");

	var yAxis = d3.svg.axis()
	    .scale(y)
	    .orient("left")

	var svg = d3.select("#figure").append("svg")
	    .attr("width", width + margin.left + margin.right)
	    .attr("height", height + margin.top + margin.bottom)
	    .attr("id", "d3-plot")
	  .append("g")
	    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	  color.domain(["Group 1", "Common group", "Group 2"]);

	  data.forEach(function(d) {
	    // calc percentages
	    d["Group 1"] = +d[1]*100/d.N;
	    d["Common group"] = +d[2]*100/d.N;
	    d["Group 2"] = +d[3]*100/d.N;

	    var x0 = -1*(d["Common group"]/2+d["Group 1"]);
	    var idx = 0;
	    d.boxes = color.domain().map(function(name) { return {name: name, x0: x0, x1: x0 += +d[name], N: +d.N, n: +d[idx += 1]}; });
	  });

	  var min_val = d3.min(data, function(d) {
	          return d.boxes["0"].x0;
	          });

	  var max_val = d3.max(data, function(d) {
	          return d.boxes["2"].x1;
	          });

	  x.domain([min_val, max_val]).nice();
	  y.domain(data.map(function(d) { return d.Annot+' '+dictGO.get(d.Annot); }));

	  svg.append("g")
	      .attr("class", "y axis")
	      .attr("fill","blue")
	      .call(yAxis);

	  var vakken = svg.selectAll(".Annot")
	      .data(data)
	      .enter().append("g")
	      .attr("class", "bar")
	      .attr("transform", function(d) { return "translate(0," + y(d.Annot+' '+dictGO.get(d.Annot)) +")"; });

	  var bars = vakken.selectAll("rect")
	      .data(function(d) { return d.boxes; })
	      .enter().append("g").attr("class", "subbar");

	  bars.append("rect")
	      .attr("height", y.rangeBand())
	      .attr("x", function(d) { return x(d.x0); })
	      .attr("width", function(d) { return x(d.x1) - x(d.x0); })
	      .style("fill", function(d) { return color(d.name); });

	  bars.append("text")
	      .attr("x", function(d) { return x(d.x0); })
	      .attr("y", y.rangeBand()/2)
	      .attr("dy", "0.5em")
	      .attr("dx", "0.5em")
	      .style("font" ,"10px sans-serif")
	      .style("text-anchor", "begin")
	      .text(function(d) { return d.n });

	  vakken.insert("rect",":first-child")
	      .attr("height", y.rangeBand())
	      .attr("x", "1")
	      .attr("width", width)
	      .attr("fill-opacity", "0.5")
	      .style("fill", "#F5F5F5")
	      .attr("class", function(d,index) { return index%2==0 ? "even" : "uneven"; });

	  svg.append("g")
	      .attr("class", "y axis")
	      .append("line")
	      .attr("x1", x(0))
	      .attr("x2", x(0))
	      .attr("y2", height);

	  var startp = svg.append("g").attr("class", "legendbox").attr("id", "mylegendbox");
	  var legend_tabs = [120, 240, 360];
	var legend = startp.selectAll(".legend")
	      .data(color.domain().slice())
	      .enter().append("g")
	      .attr("class", "legend")
	      .attr("transform", function(d, i) { return "translate(" + legend_tabs[i] + ",-45)"; });
	  
	  legend.append("rect")
	      .attr("x", 0)
	      .attr("width", 18)
	      .attr("height", 18)
	      .style("fill", color);

	  legend.append("text")
	      .attr("x", 22)
	      .attr("y", 9)
	      .attr("dy", ".35em")
	      .style("text-anchor", "begin")
	      .style("font" ,"10px sans-serif")
	      .text(function(d) { return d; });

	  d3.selectAll(".axis path")
	      .style("fill", "none")
	      .style("stroke", "#000")
	      .style("shape-rendering", "crispEdges");

	  d3.selectAll(".axis line")
	      .style("fill", "none")
	      .style("stroke", "#000")
	      .style("shape-rendering", "crispEdges");

	  //var movesize = width/2 - startp.node().getBBox().width/2;
	  //d3.selectAll(".legendbox").attr("transform", "translate(" + movesize  + ",0)");

	//Diminuer opacite de la barre ou se trouve la souris
	  var interaction = d3.selectAll(".bar")
	    .on("mouseover", function(d) { d3.select(this).attr("fill-opacity", "0.5");})
	    .on("mouseout", function(d) { d3.select(this).attr("fill-opacity", "1");});

	//Afficher infos bios supplementaires lors d'un click sur une des barres de l'histo
	  var interaction = d3.selectAll(".bar")
	    .on("click", function(d,i) { d3.select("#infos").text('\n'+d.Annot +'\n\n'+"Group 1, " + d[1] + " ID : "+'\n\n' + d.geneID1 +'\n\n'+"Common group, " + d[2] + " ID : "+'\n\n'+ d.geneIDCommon + '\n\n'+"Group 2, "  + d[3] + " ID : "+'\n\n'+ d.geneID2);});

	//Diminuer l'opacite des legendes et de l'histo au passage de la souris sur les legendes
	  var legend = startp.selectAll(".legend")
	    .on("mouseover", function(d) { interaction.attr("fill-opacity", "0.5"),d3.select(this).attr("fill-opacity", "0.5");})
	    .on("mouseout", function(d) { interaction.attr("fill-opacity", "1"),d3.select(this).attr("fill-opacity", "1");});

		var linkgo = d3.selectAll('.tick')
			.on('click',function(d){
				var GOterm = d.split(' ');
				window.open('https://www.ebi.ac.uk/QuickGO/term/'+GOterm[0]);
			});
}

//function for GOdict list
var GOtermaddf = function(){
	appendterms();
	d3.selectAll(".GOnavbox").remove();
	d3.selectAll(".GOlabels").remove();
	appendGOlist();
}
var GOtermremovef = function(){
	removeterms();
	d3.selectAll(".GOnavbox").remove();
	d3.selectAll(".GOlabels").remove();
	appendGOlist();
}
var removeterms = function(){
	var boxes = document.getElementsByClassName("GOnavbox");
	for(var i=0; i<boxes.length; i++){
		if(boxes[i].checked){
			dictGO.delete(boxes[i].value);
		}
	}
}
var appendterms = function(){
	d3.selectAll(".GOnavelem").remove();
	var guestName = document.getElementById('text');
	var listdata2 = guestName.value.split("\n");
	var listdata = [];
	for(var i=0; i<listdata2.length; i++){
		listdata[i] = listdata2[i].split(",");
	}
	for (var i=0; i<listdata.length; ++i){
		dictGO.set(listdata[i][0], listdata[i][1]);
	}
}
var appendGOlist = function(){
	var listContainer = d3.select("#listGO");
	dictGO.forEach(function(value, key, map){
		if(key != ''){
		var listdiv = listContainer.append("div");
		listdiv.append("input").attr("class", "GOnavbox").attr("id", "input"+key).attr("type","checkbox").attr("value", key);
		listdiv.append("label").attr("class", "GOlabels").attr("id", "label"+key).attr("for",key).text(key+' '+value);}
	});
}
var prepareGOlist = function(){
	var tmpGOlist = '';
	dictGO.forEach(function(value, key, map){
		tmpGOlist += key;
		tmpGOlist += ',';
	});
	tmpGOlist = tmpGOlist.substring(0,tmpGOlist.length-1);
	return tmpGOlist;
}

//	--------------- More initialized variables ---------------
var launchvenn = document.getElementById('launchvenn');
var launchbackGO = document.getElementById('launchbackGO');
var hide2 = document.getElementById('hide2');
var hide4 = document.getElementById('hide4');
var input1 = document.getElementById('input1');
var input2 = document.getElementById('input2');
var input4 = document.getElementById('GOlist');

var GOlist = loadServerFile('/textfiles/defaultGOannot.txt');
GOlist = parseGO(GOlist);//remove names, only leaving annotations

window.addEventListener('load', setupListeners);
GOtermaddf();

