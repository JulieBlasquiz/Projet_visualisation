#!python

Group_1 = []
Group_2 = []
Common_Group = []
Groups = ["Group_1", "Group_2", "Common_Group"]
nb = 0

Sum1 = 0
Sum2 = 0
SumCo = 0
Sums = []
Percentages = []

with open('result.txt', 'r') as fichier :
    for line in fichier :
            Group_1.append(line.split(',')[1])
            Common_Group.append(line.split(',')[2])
            Group_2.append(line.split(',')[3])
            Total = line.split(',')[4]
            
    for i in range (len(Group_1)):
        Sum1  = int(Sum1) + int(Group_1[i])
    Sums.append(Sum1-1)
    Tmp1 = round (( float(int (Sum1-1))/float(int (Total)))*100, 2)
    Percentages.append(Tmp1)

    for i in range (len(Group_2)):
        Sum2 = int(Sum2) + int(Group_2[i])
    Sums.append(Sum2-3)
    Tmp2 = round (( float(int (Sum2-3))/float(int (Total)))*100, 2)
    Percentages.append(Tmp2)

    for i in range (len(Common_Group)):
        SumCo = int(SumCo) + int(Common_Group[i])
    Sums.append(SumCo-2)
    TmpCo = round (( float(int (SumCo-2))/float(int (Total)))*100, 2)
    Percentages.append(TmpCo)

with open('data.txt', 'w') as fichier :
    fichier.write('groupes'+','+'proportion'+','+'pourcentage'+'\n')
    for i in range (len(Groups)):
        fichier.write((Groups[i])+','+str(Sums[i])+','+str(Percentages[i])+'\n')
                          
        
        
