
//cleanArray removes all duplicated elements - source: https://www.unicoda.com/?p=579
function cleanArray(array) {
    var len = array.length;
    var out = [];
    var obj = {};
    for (var i = 0; i < len; i++) {
	obj[array[i]] = 0;
    }
    var j;
    for (j in obj) {
	out.push(j);
    }
    return out;
}

function parsingJSON(data){
    //console.log(data)
    var listeGenesOntologiesPairs = []
    var nombreElementsGroupe1 = 0;
    var nombreElementsGroupe2 = 0;
    for(var i = 0; i<data.length; i++){
	if(data[i].Liste == 1){
	    nombreElementsGroupe1++;
	}
	if(data[i].Liste == 2){
	    nombreElementsGroupe2++;
	}
    }
    //console.log(nombreElementsGroupe1);
    //console.log(nombreElementsGroupe2);

    var listeGO = [];
    for(var i = 0; i<data.length; i++){
	listeGO.push(data[i].SlimmedGO)
    }
    var uniqueListeGO = cleanArray(listeGO);
    //console.log(uniqueListeGO);

    var JSONstring = "[";
    var jsonElement;
    for(var j = 0; j<uniqueListeGO.length; j++){
	var numberOfOccurrencesGroupe1 = 0;
	var uniprotGroupe1 = [];
	var numberOfOccurrencesGroupe2 = 0;
	var uniprotGroupe2 = [];
	for(var i = 0; i<data.length; i++){
	    if(data[i].SlimmedGO == uniqueListeGO[j] && data[i].Liste == 1){
		numberOfOccurrencesGroupe1++;
		uniprotGroupe1.push('"'+data[i].UniProtID+'"');
	    }
	    if(data[i].SlimmedGO == uniqueListeGO[j] && data[i].Liste == 2){
		numberOfOccurrencesGroupe2++;
		uniprotGroupe2.push('"'+data[i].UniProtID+'"');
	    }
	    
	}
	var uniqueUniprotGroupe1 = cleanArray(uniprotGroupe1);
	var uniqueUniprotGroupe2 = cleanArray(uniprotGroupe2);
	JSONstring = JSONstring+"{"+'"'+"GO"+'"'+":"+'"'+uniqueListeGO[j]+'"'+","+'"'+"numberOfOccurrencesGroupe1"+'"'+":"+numberOfOccurrencesGroupe1+","+'"'+"genesGroupe1"+'"'+":"+'['+uniqueUniprotGroupe1+']'+","+'"'+"numberOfOccurrencesGroupe2"+'"'+":"+numberOfOccurrencesGroupe2+","+'"'+"genesGroupe2"+'"'+":"+'['+uniqueUniprotGroupe2+']'+"}";
	JSONstring = JSONstring+",";
	//jsonElement = JSON.parse(JSONstring);
	//pseudoJSON = pseudoJSON + "{"; //faire tout en string
	//pseudoJSON.push(JSONstring);
    }
    JSONstring = JSONstring.substr(0, JSONstring.length - 1)+ ']';
    //console.log(JSONstring);
    var finalJSON = JSON.parse(JSONstring);
    console.log(finalJSON);
    return finalJSON;
}


function displayD3(rawData){

    var data = parsingJSON(rawData);
    //voir https://stackoverflow.com/questions/19236682/d3-js-bar-chart-with-pos-neg-bars-win-loss-for-each-record
    var margin = {top: 30, right: 10, bottom: 10, left: 10};
    var width = 500 - margin.left - margin.right;
    var height = 500 - margin.top - margin.bottom;

    //Echelles
    var x = d3.scale.linear()
	.range([0, width])
    
    var y = d3.scale.ordinal()
	.rangeRoundBands([0, height], .2);
 
    //Configuration des axes x et y
    var xAxis = d3.svg.axis()
	.scale(x)
	.orient("top");

    var yAxis = d3.svg.axis()
	.scale(y)
	.orient("left");
    
    //Canevas
    var svg = d3.select("body").append("svg")
	.attr("width", width + margin.left + margin.right)
	.attr("height", height + margin.top + margin.bottom)
	.append("g")
	.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    
    //Attribution des couleurs aux differents groupes
    var color = d3.scale.ordinal()
	.range(["#c7001e", "#92c6db"])
	.domain(["Groupe 1", "Groupe 2"]);
    //console.log(color);
    
    //Pour chaque élément de "data"
    data.forEach(function(d) {
	console.log(d);
	//console.log(d.GO);
	color.domain().map(function(name, length) { 
	    //console.log(name);
	    //console.log(length);
	    //return {name: name};
	});
    });

    //Fourchettes de valeurs des axes
    x.domain([-30,30])
    y.domain(data.map(function (d) {
	return d.GO;
    }));


    //Dessin des axes
    svg.append("g")
	.attr("class", "x axis")
	.call(xAxis);
    
    svg.append("g")
	.attr("class", "y axis")
	.append("line")
	.attr("x1", x(0))
	.attr("x2", x(0))
	.attr("y2", height)
	.call(yAxis);

    //Dessin des barres, côté droit
    svg.selectAll(".bar")
	.data(data)
	.enter().append("rect")
	.attr("class", "bar")
	.attr("x", function (d) {
	    return x(Math.min(0, d.numberOfOccurrencesGroupe1));
	})
	.attr("y", function (d) {
	    return y(d.GO);
	})
	.attr("width", function (d) {
	    return Math.abs(x(d.numberOfOccurrencesGroupe1) - x(0));
	})
	.attr("height", y.rangeBand())
	//.style("fill", function(d) { return color(d.name); })
	.on("mouseover", function(d) { 
	    d3.select(this).attr("fill-opacity", "0.5");
	})//Diminuer opacite de la barre ou se trouve la souris
	.on("mouseout", function(d) { 
	    d3.select(this).attr("fill-opacity", "1");
	})//Restaurer opacite de la barre ou se trouvait la souris
	.on("click", function(d,i) { 
	    d3.select("#infos")
	    //.text(d.Annot +'\n\n' +"Group 1, " + d[1] + " ID : "+'\n\n' + d.geneID1 +'\n\n'+"Common group, " + d[2] + " ID : "+'\n\n'+ d.geneIDCommon + '\n\n'+"Group 2, "  + d[3] + " ID : "+'\n\n'+ d.geneID2);
		.text(d.GO + ", "+d.numberOfOccurrencesGroupe1+", "+d.genesGroupe1);
	});//Affiche-clic


    //Dessin des barres, côté gauche    
    svg.selectAll(".bar2")
	.data(data)
	.enter().append("rect")
	.attr("class", "bar2")
	.attr("x", function (d) {
	    return x(Math.min(0, -d.numberOfOccurrencesGroupe2));
	})
	.attr("y", function (d) {
	    return y(d.GO);
	})
	.attr("width", function (d) {
	    return Math.abs(x(-d.numberOfOccurrencesGroupe2) - x(0));
	})
	.attr("height", y.rangeBand()) 
	//.style("fill", function(d) { return color(d.name); })
	.on("mouseover", function(d) { 
	    d3.select(this).attr("fill-opacity", "0.5");
	})//Diminuer opacite de la barre ou se trouve la souris
	.on("mouseout", function(d) { 
	    d3.select(this).attr("fill-opacity", "1");
	})//Restaurer opacite de la barre ou se trouvait la souris
    	.on("click", function(d,i) { 
	    d3.select("#infos")
	    //.text(d.Annot +'\n\n' +"Group 1, " + d[1] + " ID : "+'\n\n' + d.geneID1 +'\n\n'+"Common group, " + d[2] + " ID : "+'\n\n'+ d.geneIDCommon + '\n\n'+"Group 2, "  + d[3] + " ID : "+'\n\n'+ d.geneID2);
		.text(d.GO + ", "+d.numberOfOccurrencesGroupe2+", "+d.genesGroupe2);
	});//Affiche-clic

    //Légende
    var startp = svg.append("g").attr("class", "legendbox").attr("id", "mylegendbox");
    var legend_tabs = [0, 120, 240];
    var legend = startp.selectAll(".legend")
	.data(color.domain().slice())
	.enter().append("g")
	.attr("class", "legend")
	.attr("transform", function(d, i) { return "translate(" + legend_tabs[i] + ",-45)"; })
    	.on("mouseover", function(d) { 
	    d3.select(this).attr("fill-opacity", "0.5");
	})//Diminuer opacite de la légende ou se trouve la souris
	.on("mouseout", function(d) { 
	    d3.select(this).attr("fill-opacity", "1");
	});//Restaurer opacite de la légende ou se trouve la souris


    var movesize = width/2 - startp.node().getBBox().width/2;
    d3.selectAll(".legendbox") 
	.attr("transform", "translate(" + movesize  + ",0)"); //Décaler la légende
    
    legend.append("rect")
	.attr("x", 0)
	.attr("width", 18)
	.attr("height", 18)
	.style("fill", color);
    
    legend.append("text")
	.attr("x", 22)
	.attr("y", 9)
	.attr("dy", ".35em")
	.style("text-anchor", "begin")
	.style("font" ,"10px sans-serif")
	.text(function(d) { return d; });

    d3.selectAll(".axis path")
	.style("fill", "none")
	.style("stroke", "#000")
	.style("shape-rendering", "crispEdges");
    
    d3.selectAll(".axis line")
	.style("fill", "none")
	.style("stroke", "#000")
	.style("shape-rendering", "crispEdges");
	


	/*
	//Afficher infos bios supplementaires lors d'un click sur une des barres de l'histo
	var interaction = d3.selectAll(".bar")
	    .on("click", function(d,i) { 
		d3.select("#infos")
		    //.text(d.Annot +'\n\n' +"Group 1, " + d[1] + " ID : "+'\n\n' + d.geneID1 +'\n\n'+"Common group, " + d[2] + " ID : "+'\n\n'+ d.geneIDCommon + '\n\n'+"Group 2, "  + d[3] + " ID : "+'\n\n'+ d.geneID2);
		    .text(d);
	    });
*/
}

function type(d) {
    d.value = +d.value;
    return d;
}

//displayD3(data);
//var jsonFile = JSON.parse(document.getElementById('jsonFile').innerHTML);
//console.log(jsonFile);
d3.json("cutTemp", function(error, data) {
    if (error){ 
	throw error;
    }
    else{
	displayD3(data);
    }
});
