//https://steemit.com/utopian-io/@yissakhar/how-to-use-javascript-to-create-dynamic-drop-down-lists

function add_option (select_id, text) {
    var select = document.getElementById(select_id);
    select.options[select.options.length] = new Option(text);
}

function clear_combo (select_id) {
    var select = document.getElementById(select_id);
    select.options.length = 0;
}

function load_combo (select_id, option_array) {
    for (var i = 0; i < option_array.length; i++) {
	add_option (select_id, option_array[i]);
    }
}

function sel_planet_onchange () {
    var sel_planet = document.getElementById("sel_planet");
    clear_combo ("sel_moon")
    switch (sel_planet.selectedIndex){
    case 2: //Earth
	add_option ("sel_moon", "Moon");
	break;
    case 3: //Mars
	add_option ("sel_moon", "Phobos");
	add_option ("sel_moon", "Deimos");
	break;
    case 4: //Jupiter
	load_combo ("sel_moon", jupiter_moons);
	break;
    case 5: //Saturn
	load_combo ("sel_moon", saturn_moons);
	break;
    case 6: //Uranus
	load_combo ("sel_moon", uranus_moons);
	break;
    case 7: //Neptune
	load_combo ("sel_moon", neptune_moons);
	break;
    case 8:
	add_option ("sel_moon", "Charon");
	break;
	load_combo ("sel_moon", jupiter_moons)
    }
}



var planets = new Array ("Mercury", "Venus", "Earth", "Mars",
			 "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto");

load_combo ("sel_planet", planets)


var jupiter_moons = "Io, Europa, Ganymede," + "Callisto, Amalthea, Himalia, Elara, Pasiphae, Sinope, Lysithea," + " Carme, Ananke, Leda, Metis, Adrastea, Thebe, Callirrhoe, Themisto," + "Kalyke, Iocaste, Erinome, Harpalyke, Isonoe, Praxidike, Megaclite," + "Taygete, Chaldene, Autonoe, Thyone, Hermippe, Eurydome, Sponde," + "Pasithee, Euanthe, Kale, Orthosie, Euporie, Aitne";
jupiter_moons = jupiter_moons.split(",");

var saturn_moons = "Titan, Rhea, Iapetus," + "Dione, Tethys, Enceladus, Mimas, Hyperion, Prometheus, Pandora," + "Phoebe, Janus, Epimetheus, Helene, Telesto, Calypso, Atlas," + "Pan, Ymir, Paaliaq, Siarnaq, Tarvos, Kiviuq, Ijiraq, Thrym, Skadi," + "Mundilfari, Erriapo, Albiorix, Suttung";
saturn_moons = saturn_moons.split(",");

var uranus_moons = "Cordelia, Ophelia, Bianca," + "Cressida, Desdemona, Juliet, Portia, Rosalind, Belinda, Puck," + "Miranda, Ariel, Umbriel, Titania, Oberon, Caliban, Sycorax," + "Prospero, Setebos, Stephano, Trinculo";
uranus_moons = uranus_moons.split(",");

var neptune_moons = "Triton, Nereid, Naiad," + "Thalassa, Despina, Galatea, Larissa, Proteus";
neptune_moons = neptune_moons.split(",");






document.getElementById('sel_planet').onclick = sel_planet_onchange;
