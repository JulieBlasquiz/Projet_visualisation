'use strict'

let express = require('express');  
let app     = express();

app.post('/raw', (req, res) => {

  // output the headers
  console.log(req.headers);

  // capture the encoded form data
  req.on('data', (data) => {
    console.log(data.toString());
  });

  // send a response when finished reading
  // the encoded form data
  req.on('end', () => {
    res.send('ok');
  });
});

// start server on port 8080
app.listen(8080);  


//http://derpturkey.com/node-multipart-form-data-explained/

//installer et utiliser multer (package pour express) pour les uploads de fichiers: https://github.com/expressjs/multer


