function add_option (select_id, text) {
    var select = document.getElementById(select_id);
    select.options[select.options.length] = new Option(text);
}

function clear_combo (select_id) {
    var select = document.getElementById(select_id);
    select.options.length = 0;
}

function load_combo (select_id, option_array) {
    for (var i = 0; i < option_array.length; i++) {
	add_option (select_id, option_array[i]);
    }
}

function convertStringReturnToList(item){
    var fileToList = item.split("\r\n");
    //console.log(fileToList);
    return fileToList;
}

function convertStringCommaToList(item){
    var fileToList = item.split(",");
    //console.log(fileToList);
    return fileToList;
}


function loadFile(filename){
    var fileInput = document.querySelector('#ontologies');
    fileInput.addEventListener('change', function() {
	var reader = new FileReader();
	reader.readAsText(fileInput.files[0]);
	reader.addEventListener('load', function() {
	    console.log(reader.result);
	    alert('Contenu du fichier "' + fileInput.files[0].name + '" :\n\n' + reader.result);
	    pipeline(reader.result);
	});
    });
}


function pipeline(reader){
    var ontologies = convertStringReturnToList(reader);
    load_combo("GO_ontology",reader);
}



function setupListeners(){
    window.addEventListener("click", loadFile);
}


window.addEventListener("load", setupListeners)



//charger le fichier depuis le serveur -> nodejs interviendra là
//https://stackoverflow.com/questions/26218243/dynamic-dropdown-in-node-js
//https://www.codebyamir.com/blog/populate-a-select-dropdown-list-with-json
//https://medium.com/@micahbales/how-to-programmatically-select-items-in-an-html-dropdown-menu-including-multiple-selections-f1797d0ae268
