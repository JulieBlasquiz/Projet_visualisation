function chargerListeGO(fichier){
    var reader = new FileReader();
    reader.readAsText(fileInput.files[0]);
    return reader;
}


function convertToList(reader){
    var genesList = reader.split("\r\n");
    return genesList;
}

function setupListeners(){
    var fichierGO = chargerListeGO("./refs/GO_description.tab");
    //var fichierGO = chargerListeGO("./refs/example.tab");
    var GOlist = convertToList(fichierGO);
    var HTMLontologiesList = document.getElementById("newListedOntology")
    for(var i = 0; i<GOlist.size; i++){
	var listedOntology = document.createElement("option");
	listedOntology.id = "listedOntology";
	listedOntology.value = GOlist[i];
	listedOntology.innerHTML = GOlist[i];
	HTMLontologiesList.appendChild(listedOntology);
    }
}

window.addEventListener("load", setupListeners);
