var http = require('http');
var url = require('url');
var fs = require('fs');

var querystring = require('querystring'); //installer tout ça
var express = require('express');
var session = require('cookie-session'); // Charge le middleware de sessions
var bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres

var request = require('request');
var rp = require('request-promise');

var quickgo = require('bionode-quickgo');

//var server = http.createServer(); //Pas besoin, créé automatiquement grâce à express
var app = express();
var urlencodedParser = bodyParser.urlencoded({ extended: false });



/* On utilise les sessions */
app.use(session({secret: 'quickgo'}));

/* S'il n'y a pas de liste de gènes dans la session,
on en crée une vide sous forme d'array avant la suite */
app.use(function(req, res, next){
    if (typeof(req.session.genesList1) == 'undefined') {
        req.session.genesList1 = [];
    }
    if (typeof(req.session.genesList2) == 'undefined') {
        req.session.genesList2 = [];
    }
    if (typeof(req.session.ontologiesList) == 'undefined') {
	req.session.ontologiesList = [];
    }
    next();
});


/* On affiche la liste de gènes, la liste d'ontologies et le formulaire */
app.get('/', function(req, res) { 
    res.render('quick_go_example.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
});

/* On envoie le script client */ //problème ici
app.get('/client.js', function(req, res) { 
    script = fs.readFileSync("client.js", "utf8");
    res.write(script);
    //res.render('quick_go_example.ejs', {genesList: req.session.genesList, ontologiesList: req.session.ontologiesList});
    res.redirect('/');
});

/* On ajoute un élément à la liste de gènes 1 */
app.post('/ajouter_gene_liste_1/', urlencodedParser, function(req, res) {
    if (req.body.newGene_liste_1 != '') {
        req.session.genesList1.push(req.body.newGene_liste_1);
    }
    res.redirect('/');
});

/* On ajoute un fichier de liste de gènes 1 */
app.post('/ajouter_liste_gene_liste_1/', urlencodedParser, function(req, res) {
    if (req.body.fileGenes_liste_1 != '') {
	console.log(req.body.fileGenes_liste_1); 
	//var stringGenes = fs.readFileSync(req.body.fileGenes, "UTF-8");
	//var listeGenes = stringGenes.split(",");
	var listeGenes = fs.readFileSync(req.body.fileGenes_liste_1, "UTF-8");
	//parser le fichier pour tout entrer dans genesList
        req.session.genesList1.concat(listeGenes);
    }
    res.redirect('/');
});

/* Supprime un élément de la liste de gènes 1 */
app.get('/supprimer_gene_liste_1/:id', function(req, res) {
    if (req.params.id != '') {
        req.session.genesList1.splice(req.params.id, 1);
    }
    res.redirect('/');
});


/* On ajoute un élément à la liste de gènes 2 */
app.post('/ajouter_gene_liste_2/', urlencodedParser, function(req, res) {
    if (req.body.newGene_liste_2 != '') {
        req.session.genesList2.push(req.body.newGene_liste_2);
    }
    res.redirect('/');
});

/* On ajoute un fichier de liste de gènes 2 */
app.post('/ajouter_liste_gene_liste_2/', urlencodedParser, function(req, res) {
    if (req.body.fileGenes_liste_2 != '') {
	console.log(req.body.fileGenes_liste_2); 
	//var stringGenes = fs.readFileSync(req.body.fileGenes, "UTF-8");
	//var listeGenes = stringGenes.split(",");
	var listeGenes = fs.readFileSync(req.body.fileGenes_liste_2, "UTF-8");
	//parser le fichier pour tout entrer dans genesList
        req.session.genesList2.concat(listeGenes);
    }
    res.redirect('/');
});

/* Supprime un élément de la liste de gènes 2*/
app.get('/supprimer_gene_liste_2/:id', function(req, res) {
    if (req.params.id != '') {
        req.session.genesList2.splice(req.params.id, 1);
    }
    res.redirect('/');
});

//Parser la liste de gènes
app.use(function(req, res, next){
});

/* On ajoute un élément à la liste d'ontologies */
app.post('/ajouter_ontology/', urlencodedParser, function(req, res) {
    if (req.body.newOntology != '') {
        req.session.ontologiesList.push(req.body.newOntology);
    }
    res.redirect('/');
});

app.post('/ajouter_ontology_from_list/', urlencodedParser, function(req, res) {
    if (req.body.newListedOntology != '') {
        req.session.ontologiesList.push(req.body.newListedOntology);
    }
    res.redirect('/');
});


/* Supprime un élément de la liste d'ontologies */
app.get('/supprimer_ontology/:id', function(req, res) {
    if (req.params.id != '') {
        req.session.ontologiesList.splice(req.params.id, 1);
    }
    res.redirect('/');
});

/* On redirige vers la todolist si la page demandée n'est pas trouvée */
app.use(function(req, res, next){
    res.redirect('/');
});

app.use(function(req, res){ // Répond enfin
    res.send(genesList);
    res.send(ontologiesList);
});

//En cas de page introuvable

app.use(function(req, res, next){
    res.setHeader('Content-Type', 'text/plain');
    res.status(404).send('Page introuvable !');
});


app.on('close', function() { // On écoute l'évènement close
    console.log('Bye bye !');
});

app.listen(8081);

//Node.js est très bas niveau : on récupère l'URL qu'on doit ensuite parser grâce à plusieurs méthodes, pour déterminer le nom de la page réclamée par le visiteur.
