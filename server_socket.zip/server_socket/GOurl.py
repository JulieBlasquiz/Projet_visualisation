import requests, sys, json

def roundup(number):
	if(number%25 == 0):
		number = number/25
	else:
		number = 1+number/25
	return number

def parse_data(data):
	data = data.split(";")
	for i in range(3):
		data[i] = data[i][0:len(data[i])-1]
	for j in range(2):
		tmp = data[j].split(",")
		for i in range(len(tmp)-1):
			tmp[i]+='%2C%20'
			data[j] = ''.join(tmp)
	tmp = data[2]
	data[2] = tmp.replace(":","%3A")
	data[2] = data[2].replace("\n",'')
	return data

def read_in():
	lines = sys.stdin.readlines()
	#Since our input would only be having one line, parse our JSON data from that
	return json.loads(lines[0])

def sendquick(nbpage, nbfile, nbhits, data, pagestot):
	requestURL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?page="+str(nbpage)+"&geneProductId="+data[nbfile]+"&goId="+data[2]+"&goUsage=slim&goUsageRelationships=is_a,part_of&geneProductType=protein"

	r = requests.get(requestURL, headers= {"Accept" : "application/json"})
	if not r.ok:
		print r.text
		print requestURL
		r.raise_for_status()
		sys.exit()
	
	
	if(nbpage == 1):
		splitter = r.text.split(":")
		pagestot[0] = splitter[-1]
		pagestot[0] = pagestot[0].replace("}}",'')
		pagestot[0] = len(pagestot[0])
		datareturn = r.text[0:len(r.text)-(56+pagestot[0])]
	elif (nbpage > 99):
		datareturn = r.text[nbhits+28:len(r.text)-(58+pagestot[0])]
	elif(nbpage > 9):
		datareturn = r.text[nbhits+28:len(r.text)-(57+pagestot[0])]
	else:
		datareturn = r.text[nbhits+28:len(r.text)-(56+pagestot[0])]
	return datareturn


data = read_in()
data = parse_data(data)
Finaldata = ''

for j in range(2):
	pagestot = [1]
	responseBody = sendquick(1,j,0,data,pagestot)
	responseBody+=","
	nbhits = responseBody.split(":")
	nbhits = nbhits[1].split(",")
	nbhits = int(nbhits[0])
	nbpages = roundup(nbhits)
	nbhits = len(str(nbhits))

	for i in range(2,nbpages+1):
		responseBody+=sendquick(i,j,nbhits,data,pagestot)
		responseBody+=","
	
	Finaldata+=responseBody[0:len(responseBody)-1]+"]}  "

print Finaldata




