import requests, sys, json

def read_in():
	lines = sys.stdin.readlines()
	#Since our input would only be having one line, parse our JSON data from that
	return json.loads(lines[0])

def sendquick(nbpage, nbfile, nbhits, data):
	requestURL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?page="+str(nbpage)+"&geneProductId="+data[nbfile]+"&goId="+data[2]+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein"

	r = requests.get(requestURL, headers= {"Accept" : "application/json"})
	if not r.ok:
		print "error"
		r.raise_for_status()
		sys.exit()
	
	if(nbpage == 1):
		datareturn = r.text[0:len(r.text)-58]
	elif (nbpage > 99):
		datareturn = r.text[nbhits+28:len(r.text)-60]
	elif(nbpage > 9):
		datareturn = r.text[nbhits+28:len(r.text)-59]
	else:
		datareturn = r.text[nbhits+28:len(r.text)-58]
	return datareturn

def parse_data(data):
	data = data.split(";")
	for i in range(3):
		data[i] = data[i][0:len(data[i])-1]
	for j in range(2):
		tmp = data[j].split(",")
		for i in range(len(tmp)-1):
			tmp[i]+='%2C%20'
			data[j] = ''.join(tmp)
	tmp = data[2]
	data[2] = tmp.replace(":","%3A")
	data[2] = data[2].replace("\n",'')
	return data



#print "start"
data = read_in()
#print data
data = parse_data(data)
#print "finparse"

Finaldata = ''

for j in range(2):
	responseBody = sendquick(1,j,0,data)
	responseBody+=","

	nbhits = responseBody.split(":")
	nbhits = nbhits[1].split(",")
	nbhits = int(nbhits[0])
	nbpages = 1+nbhits/25
	nbhits = len(str(nbhits))

	for i in range(2,nbpages+1):
		responseBody+=sendquick(i,j,nbhits,data)
		responseBody+=","
	
	Finaldata+=responseBody[0:len(responseBody)-1]+"]}  "

print Finaldata




