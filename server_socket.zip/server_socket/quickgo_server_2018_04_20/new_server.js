'use strict' //Toujours l'utiliser. Plus d'infos ici: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Strict_mode

/*----------------------------------NodeJS--------------------------------------*/

// ---------------- Modules de base, indispensables pour à peu près tout

const url = require('url'); //Pour utilisation d'URLs
const fs = require('fs'); //Pour transferts de fichiers
const bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
const urlencodedParser = bodyParser.urlencoded({ extended: false });


// ---------------- Utilisation d'Express

//var server = http.createServer(); //Pas besoin, créé automatiquement grâce à express
const express = require('express'); //Framework de design de serveurs nodejs
const app = express();
var server = require('http').Server(app);
app.use(express.static(__dirname)); //Utilisation du répertoire par défaut pour les fichiers annexes
const multer = require('multer'); //Gestion des transferts de fichiers - Nécessite Express
//let upload = multer({storage: multer.memoryStorage()});
const upload = multer({ dest: 'uploads/' });

var querystring = require('querystring');
var session = require('cookie-session'); // Charge le middleware de sessions
app.use(session({secret: 'quickgo'})); // Utilisation d'un système de sessions


// ---------------- Modules destinés aux requêtes externes. On n'utilise que request car simple et rapide d'utilisation. Les modules http et https obligent à mettre les mains dans le cambouis.

const http = require('http');
const https = require('https');
const csp = require('helmet-csp'); // Gestion de la Content-Security-Policy. Utilisé avec les modules http et https - voir: https://ponyfoo.com/articles/content-security-policy-in-express-apps et https://helmetjs.github.io/docs/csp/
app.use(csp({
    directives: {
	defaultSrc: ["'self'"], //"data:", '"unsafe-inline"','"unsafe-eval"'],
	scriptSrc: ["'self'"], //'"unsafe-inline"','"unsafe-eval"'],
	connectSrc: ["'self'", 'ebi.ac.uk'],
	imgSrc: ["'self'"]
    }
}));
const request = require('request'); //Utilisé ici
const rp = require('request-promise');


// ---------------- Script serveur

// autorisation du script d3js
app.use(function(req, res, next) {
    res.setHeader("Content-Security-Policy", "script-src 'self' http://cdnjs.cloudflare.com/ajax/libs/d3/3.4.13/d3.min.js");
    return next();
});


/* On affiche la liste de gènes, la liste d'ontologies et le formulaire */
app.get('/', function(req, res) {
    console.log("Rendering HTML page");
    res.render('new_try.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
});


// On envoie le script client
app.post('/client.js', function(req, res) {
    console.log("Posting client JS script");
    script = fs.readFileSync("client.js", "utf8");
    res.write(script);
    res.render('new_try.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
    res.redirect('/');
});

// Process application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: true}))

// Process application/json
app.use(bodyParser.json());

app.post('/client.js', function(req, res){  
//now req.body will be populated with the object you sent
console.log(req.body); //prints 
});


//En cas de page introuvable
app.get(function(req, res){
    res.setHeader('Content-Type', 'text/plain');
    console.log("Error detected, redirecting to form");
    res.status(404).send('Page introuvable !');
    res.redirect('/');
});

app.on('close', function() { // On écoute l'évènement close
    console.log('Bye bye !');
});

// --------------socket io
var io = require("socket.io")(server);

// Quand un client se connecte, on le note dans la console
io.sockets.on('connection', function (socket) {
	console.log("connexion sur le server");

	// Quand le serveur reçoit un signal de type "message" du client    
	socket.on('message', function (message) {
		//remove first element to use it as comparison test
		var messagetype = message.split(";");
		message = messagetype.slice(1);
		message = message.join(';');
		
		if (messagetype[0] == "david"){
		// launch python script
			var spawn = require('child_process').spawn,
			py = spawn('python', ['python_Kegg_without_table_report_var/newClient/DAVIDWebService_Client.py']),
			data = message,
			dataString = '';
			py.stdout.on('data', function(data){
				dataString += data.toString();
			});
			//show data in terminal and send to html
			py.stdout.on('end', function(){
				console.log('from david:',dataString);
				socket.emit("message", dataString);
			});
			py.stdin.write(JSON.stringify(data));
			py.stdin.end();
		}
		else if(messagetype[0] == 'quickGO'){
			console.log("data received for quickGO");
			var spawn = require('child_process').spawn,
			py = spawn('python', ['pythonurl.py']),
			data = message,
			dataString = '';
			py.stdout.on('data', function(data){
				dataString += data.toString();
			});
			//show data in terminal and send to html
			py.stdout.on('end', function(){
				console.log('from quickgo:',dataString);
				socket.emit("message", dataString);
			});
			py.stdin.write(JSON.stringify(data));
			py.stdin.end();
		}
	});
});


server.listen(8082);


