/**
BLASQUIZ Julie
LUCK Romain
MONGY Marc
RAFFAELLI Michele
14/05/2018
*/

'use strict' //Toujours l'utiliser. Plus d'infos ici: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Strict_mode

/*----------------------------------NodeJS--------------------------------------*/

// ---------------- Modules de base, indispensables pour à peu près tout

const url = require('url'); //Pour utilisation d'URLs
const fs = require('fs'); //Pour transferts de fichiers
const bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
const urlencodedParser = bodyParser.urlencoded({ extended: false });


// ---------------- Utilisation d'Express

//var server = http.createServer(); //Pas besoin, créé automatiquement grâce à express
const express = require('express'); //Framework de design de serveurs nodejs
const app = express();
var server = require('http').Server(app);
app.use(express.static(__dirname)); //Utilisation du répertoire par défaut pour les fichiers annexes

var session = require('cookie-session'); // Charge le middleware de sessions
app.use(session({secret: 'quickgo'})); // Utilisation d'un système de sessions

// ---------------- Modules destinés aux requêtes externes. On n'utilise que request car simple et rapide d'utilisation. Les modules http et https obligent à mettre les mains dans le cambouis.

const http = require('http');
const https = require('https');
const csp = require('helmet-csp'); // Gestion de la Content-Security-Policy. Utilisé avec les modules http et https - voir: https://ponyfoo.com/articles/content-security-policy-in-express-apps et https://helmetjs.github.io/docs/csp/
app.use(csp({
    directives: {
	defaultSrc: ["'self'"], //"data:", '"unsafe-inline"','"unsafe-eval"'],
	scriptSrc: ["'self'"], //'"unsafe-inline"','"unsafe-eval"'],
	connectSrc: ["'self'", 'ebi.ac.uk'],
	imgSrc: ["'self'"]
    }
}));
const request = require('request'); //Utilisé ici

// ---------------- Script serveur

// autorisation du script d3js
app.use(function(req, res, next) {
    res.setHeader("Content-Security-Policy", "script-src 'self' http://cdnjs.cloudflare.com/ajax/libs/d3/3.4.13/d3.min.js");
    return next();
});

/* On affiche la liste de gènes, la liste d'ontologies et le formulaire */
app.get('/', function(req, res) {
    //console.log("Rendering HTML page");
    res.render('main_page.ejs');
});
app.get('/manual', function(req, res) {
    //console.log("Rendering HTML page");
    res.render('user_manual.ejs');
});
app.get('/defaultGO', function(req, res) {
    //console.log("Rendering HTML page");
    res.render('defaultslim.ejs');
});
app.get('/contacts', function(req, res) {
    //console.log("Rendering HTML page");
    res.render('contacts.ejs');
});
app.get('/about_us', function(req, res) {
    //console.log("Rendering HTML page");
    res.render('about_us.ejs');
});
// Process application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: true}))

// Process application/json
app.use(bodyParser.json());

//En cas de page introuvable
app.get(function(req, res){
    res.setHeader('Content-Type', 'text/plain');
    console.log("Error detected, redirecting to form");
    res.status(404).send('Page introuvable !');
    res.redirect('/');
});

// --------------socket io
var io = require("socket.io")(server);
io.sockets.on('connection', function (socket) {
	socket.on('message', function (message) {
		//remove first element to use it as comparison test
		var messagetype = message.split(";");
		message = messagetype.slice(1);
		message = message.join(';');
		
		if(messagetype[0] == 'quickGO'){
			//console.log("data received for quickGO");
			var spawn = require('child_process').spawn,
			py = spawn('python', ['GOurl.py']),
			data = message,
			dataString = '';
			py.stdout.on('data', function(data){
				dataString += data.toString();
			});
			//show data in terminal and send to html
			py.stdout.on('end', function(){
				console.log('from quickgo:',dataString);
				socket.emit("message", dataString);
			});
			py.stdin.write(JSON.stringify(data));
			py.stdin.end();
		}
	});
});


server.listen(8082);


