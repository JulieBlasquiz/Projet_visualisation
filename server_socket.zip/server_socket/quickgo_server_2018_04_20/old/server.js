'use strict'




/*----------------------------------NodeJS--------------------------------------*/

var http = require('http');
var https = require('https');
var url = require('url');
var fs = require('fs');

//var server = http.createServer(); //Pas besoin, créé automatiquement grâce à express
var express = require('express');
var app = express();

//Gestion des tansferts de fichiers
let multer = require('multer');
//let upload = multer({storage: multer.memoryStorage()});
var upload = multer({ dest: 'uploads/' });

var querystring = require('querystring');

var session = require('cookie-session'); // Charge le middleware de sessions
var bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
var urlencodedParser = bodyParser.urlencoded({ extended: false });

var request = require('request');
var rp = require('request-promise');

var quickgo = require('bionode-quickgo');
var obo = require('bionode-obo');




/* On utilise les sessions */
app.use(session({secret: 'quickgo'}));

/* S'il n'y a pas de liste de gènes dans la session,
on en crée une vide sous forme d'array avant la suite */
app.use(function(req, res, next){
    if (typeof(req.session.genesList1) == 'undefined') {
        req.session.genesList1 = [];
    }
    if (typeof(req.session.genesList2) == 'undefined') {
        req.session.genesList2 = [];
    }
    
    if (typeof(req.session.ontologiesList) == 'undefined') {
	req.session.ontologiesList = [];
    }

    if (typeof(req.session.data) == 'undefined') {
	req.session.data = [];
    }
    next();
});


/* On affiche la liste de gènes, la liste d'ontologies et le formulaire */
app.get('/', function(req, res, next) { 
    res.render('quick_go_example.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
});

//app.use('/static', express.static(__dirname + '/static'));
app.use(express.static(__dirname));


// On envoie le script client  //problème ici
app.get('/client.js', function(req, res, next) { 
    script = fs.readFileSync("client.js", "utf8");
    res.write(script);
    res.render('quick_go_example.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
    res.redirect('/');
});

/* On ajoute un élément à la liste de gènes 1 */
app.post('/ajouter_gene_liste_1/', urlencodedParser, function(req, res, next) {
    if (req.body.newGene_liste_1 != '') {
        req.session.genesList1.push(req.body.newGene_liste_1);
    }
    res.redirect('/');
});

/* On ajoute un fichier de liste de gènes 1 */
app.post('/ajouter_liste_gene_liste_1/', upload.single('fileGenes_liste_1'), function(req, res, next) {
    if (req.body.newGene_liste_1 != '') {
	if (req.file) {
	    console.log(req.file);
	    var stringGenes = fs.readFileSync(req.file.path, "UTF-8");
	    var listeGenes = stringGenes.split("\n");
	    //parser le fichier pour tout entrer dans genesList
	    for(var i = 0; i<listeGenes.length; i++){
		req.session.genesList1.push(listeGenes[i]);
	    }
	    //console.log(genes1);
            //req.session.genesList1.concat(listeGenes); //concat ne marche pas
	}
    }
    res.redirect('/');
});

/* Supprime un élément de la liste de gènes 1 */
app.get('/supprimer_gene_liste_1/:id', function(req, res, next) {
    if (req.params.id != '') {
        req.session.genesList1.splice(req.params.id, 1);
    }
    res.redirect('/');
});


/* On ajoute un élément à la liste de gènes 2 */
app.post('/ajouter_gene_liste_2/', urlencodedParser, function(req, res, next) {
    if (req.body.newGene_liste_2 != '') {
        req.session.genesList2.push(req.body.newGene_liste_2);
    }
    res.redirect('/');
});

/* On ajoute un fichier de liste de gènes 2 */
app.post('/ajouter_liste_gene_liste_2/', upload.single('fileGenes_liste_2'), function(req, res, next) {
    if (req.body.newGene_liste_2 != '') {
	if (req.file) {
	    console.log(req.file);
	    var stringGenes = fs.readFileSync(req.file.path, "UTF-8");
	    var listeGenes = stringGenes.split("\n");
	    //parser le fichier pour tout entrer dans genesList
	    for(var i = 0; i<listeGenes.length; i++){
		req.session.genesList2.push(listeGenes[i]);
	    }
	    //console.log(genes2);
	}
    }
    res.redirect('/');
});

/* Supprime un élément de la liste de gènes 2*/
app.get('/supprimer_gene_liste_2/:id', function(req, res, next) {
    if (req.params.id != '') {
        req.session.genesList2.splice(req.params.id, 1);
    }
    res.redirect('/');
});


/* On ajoute un élément à la liste d'ontologies */
app.post('/ajouter_ontology/', urlencodedParser, function(req, res, next) {
    if (req.body.newOntology != '') {
        req.session.ontologiesList.push(req.body.newOntology);
    }
    res.redirect('/');
});

/* Liste d'ontologies déroulante */
app.post('/ajouter_ontology_from_list/', upload.single('newListedOntology'), function(req, res, next) {			   
    if (req.body.newListedOntology != '') {
        req.session.ontologiesList.push(req.body.newListedOntology);
    }
    res.redirect('/');
});

/* On ajoute un fichier OBO */
app.post('/ajouter_obo/', upload.single('oboList'), function(req, res, next) {
    if (req.file) {
	console.log(req.file);
	//var oboStream = fs.readFileSync(req.file.path, "UTF-8");
	fs.stat(file, (err, stat) => {
	    let total = stat.size
	    let progress = 0
	    var oboStream = fs.createReadStream(req.file.path);
	    console.log(oboStream);
	    oboStream.on('data', (chunk) => {
		progress += chunk.length
		console.log("J'ai lu " + Math.round(100 * progress / total) + "%")
	    })
	})
	
	var oboOntologyTerms = obo.terms(oboStream);
	console.log(oboOntologyTerms);
	var listeGenes = oboStream.split("\n");
	for(var i = 0; i<oboOntologyTerms.length; i++){
	    req.session.ontologiesList.push(oboOntologyTerms[i]);
	}

   }
    res.redirect('/');
});


/* Supprime un élément de la liste d'ontologies */
app.get('/supprimer_ontology/:id', function(req, res, next) {
    if (req.params.id != '') {
        req.session.ontologiesList.splice(req.params.id, 1);
    }
    res.redirect('/');
});

/* On redirige vers la todolist si la page demandée n'est pas trouvée */
app.use(function(req, res, next){
    res.redirect('/');
});

app.use(function(req, res){ // Répond enfin
    res.send(req.session.genesList1);
    res.send(req.session.genesList2);
    res.send(req.session.ontologiesList);
    res.redirect('/');
});


app.post('/send_quickgo', urlencodedParser, function(req, res, next){
    var genes1 = req.session.genesList1;
    var genes2 = req.session.genesList2;
    var quickGOrequest = quickgo.GAnnotation("geneProductId="+genes1+genes2+"&"+"geneProductType=protein");
    //var result = quickgo.GAnnotation(goId=GO:0003677,GO:0000278,GO:0000902,GO:0000988&goUsageRelationships=is_a&goUsage=slim&geneProductType=protein&geneProductId=UniProtKB:Q6FNY0,UniProtKB:Q6FNY6,UniProtKB:Q6FP08,UniProtKB:Q6FP28,UniProtKB:Q6FPA8,UniProtKB:Q6FPE6,UniProtKB:Q6FPF5,UniProtKB:Q6FPI0,UniProtKB:Q6FPR9,UniProtKB:Q6FPV9,UniProtKB:Q6FPZ8,UniProtKB:Q6FQ10,UniProtKB:Q6FQ30,UniProtKB:Q6FQ47,UniProtKB:Q6FQA4,UniProtKB:Q6FQI0,UniProtKB:Q6FQL2,UniProtKB:Q6FQR9,UniProtKB:Q6FQW5,UniProtKB:Q6FQY3,UniProtKB:Q6FR39,UniProtKB:Q6FR69,UniProtKB:Q6FRA7,UniProtKB:Q6FRB5,UniProtKB:Q6FRC7,UniProtKB:Q6FRH5,UniProtKB:Q6FRJ5,UniProtKB:Q6FRP1,UniProtKB:Q6FRR3,UniProtKB:Q6FRT2,UniProtKB:Q6FRV5,UniProtKB:Q6FRZ7,UniProtKB:Q6FS34,UniProtKB:Q6FS38,UniProtKB:F2Z6H6,UniProtKB:Q6FS82,UniProtKB:Q6FS86,UniProtKB:Q6FSA8,UniProtKB:Q6FSD9,UniProtKB:Q6FSK0,UniProtKB:Q6FSM6,UniProtKB:Q6FSM9,UniProtKB:Q6FSQ4,UniProtKB:Q6FT29,UniProtKB:Q6FT61,UniProtKB:Q6FTA9,UniProtKB:Q6FTD9,UniProtKB:Q6FTH2,UniProtKB:Q6FTJ1,UniProtKB:Q6FTJ9,UniProtKB:Q6FTN5,UniProtKB:Q6FTQ4,UniProtKB:Q6FTU9,UniProtKB:Q6FUA3,UniProtKB:Q6FUB0,UniProtKB:Q6FUB2,UniProtKB:Q6FUD4,UniProtKB:Q6FUQ2,UniProtKB:Q6FUU4,UniProtKB:Q6FUW0,UniProtKB:Q6FUX7,UniProtKB:Q6FV32,UniProtKB:Q6FV55,UniProtKB:Q6FV87,UniProtKB:Q6FVD1,UniProtKB:Q6FVH8,UniProtKB:Q6FVQ2,UniProtKB:Q6FVS5,UniProtKB:Q6FW00,UniProtKB:Q6FW60,UniProtKB:Q6FWD2,UniProtKB:Q6FWF0,UniProtKB:Q6FWH2,UniProtKB:Q6FWK9,UniProtKB:Q6FWL8,UniProtKB:Q6FWM2,UniProtKB:Q6FWS3,UniProtKB:Q6FWT3,UniProtKB:Q6FWU1,UniProtKB:Q6FWW0,UniProtKB:Q6FWY1,UniProtKB:Q6FXL6,UniProtKB:Q6FXQ9,UniProtKB:Q6FXR3,UniProtKB:Q6FXI6,UniProtKB:Q6FXJ5,UniProtKB:Q6FXE4,UniProtKB:Q6FY54,UniProtKB:Q6FYB3,UniProtKB:Q6FX56,UniProtKB:Q6FX93&reference=GO_REF&qualifier=enables&assignedBy=EnsemblFungi);
    //var result = quickgo.GAnnotation("GO:0003677");
    //console.log(result);
    console.log(quickGOrequest);
    res.redirect('/');
});


app.get('/send_quickgo_webservice', urlencodedParser, function(req, res, next){
    /*
    var genes1 = req.session.genesList1;
    var genes2 = req.session.genesList2;
    var stringGenes = "";
    var ontologies = req.session.ontologiesList;
    var stringOntologies = "";

    for(var i = 0; i<genes1.length; i++){
	stringGenes = stringGenes+genes1[i]+",";
    }
    for(var j = 0; j<genes2.length; j++){
	stringGenes = stringGenes+genes2[j]+",";
    }
    stringGenes = stringGenes.substring(0,stringGenes.length-1);
    console.log(stringGenes);
    
    for(var k = 0; k<ontologies.length; k++){
	stringOntologies = stringOntologies+ontologies[k]+",";
    }
    stringOntologies = stringOntologies.substring(0,stringOntologies.length-1);
    console.log(stringOntologies);

    if (req.body.data != '') {
        req.session.data.push(stringGenes);
	req.session.data.push(stringOntologies);
    }
    
    //var genes1 = "Q6FP08";
    //var genes2 = "Q6FP28";
    //var ontologies = "GO:0000988";

    var data = JSON.stringify({
	'id': '2'
    });
    //var targetURL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+stringGenes+"&goId="+stringOntologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";
    var targetURL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+req.session.data[0]+"&goId="+req.session.data[1]+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";
*/

    var genes = "UniProtKB:Q6FNY0,UniProtKB:Q6FNY6,UniProtKB:Q6FP08,UniProtKB:Q6FP28,UniProtKB:Q6FPA8,UniProtKB:Q6FPE6,UniProtKB:Q6FPF5,UniProtKB:Q6FPI0,UniProtKB:Q6FPR9,UniProtKB:Q6FPV9,UniProtKB:Q6FPZ8,UniProtKB:Q6FQ10,UniProtKB:Q6FQ30,UniProtKB:Q6FQ47,UniProtKB:Q6FQA4,UniProtKB:Q6FQI0,UniProtKB:Q6FQL2,UniProtKB:Q6FQR9,UniProtKB:Q6FQW5,UniProtKB:Q6FQY3,UniProtKB:Q6FR39,UniProtKB:Q6FR69,UniProtKB:Q6FRA7,UniProtKB:Q6FRB5,UniProtKB:Q6FRC7,UniProtKB:Q6FRH5,UniProtKB:Q6FRJ5,UniProtKB:Q6FRP1,UniProtKB:Q6FRR3,UniProtKB:Q6FRT2,UniProtKB:Q6FRV5,UniProtKB:Q6FRZ7,UniProtKB:Q6FS34,UniProtKB:Q6FS38,UniProtKB:F2Z6H6,UniProtKB:Q6FS82,UniProtKB:Q6FS86,UniProtKB:Q6FSA8,UniProtKB:Q6FSD9,UniProtKB:Q6FSK0,UniProtKB:Q6FSM6,UniProtKB:Q6FSM9,UniProtKB:Q6FSQ4,UniProtKB:Q6FT29,UniProtKB:Q6FT61,UniProtKB:Q6FTA9,UniProtKB:Q6FTD9,UniProtKB:Q6FTH2,UniProtKB:Q6FTJ1,UniProtKB:Q6FTJ9,UniProtKB:Q6FTN5,UniProtKB:Q6FTQ4,UniProtKB:Q6FTU9,UniProtKB:Q6FUA3,UniProtKB:Q6FUB0,UniProtKB:Q6FUB2,UniProtKB:Q6FUD4,UniProtKB:Q6FUQ2,UniProtKB:Q6FUU4,UniProtKB:Q6FUW0,UniProtKB:Q6FUX7,UniProtKB:Q6FV32,UniProtKB:Q6FV55,UniProtKB:Q6FV87,UniProtKB:Q6FVD1,UniProtKB:Q6FVH8,UniProtKB:Q6FVQ2,UniProtKB:Q6FVS5,UniProtKB:Q6FW00,UniProtKB:Q6FW60,UniProtKB:Q6FWD2,UniProtKB:Q6FWF0,UniProtKB:Q6FWH2,UniProtKB:Q6FWK9,UniProtKB:Q6FWL8,UniProtKB:Q6FWM2,UniProtKB:Q6FWS3,UniProtKB:Q6FWT3,UniProtKB:Q6FWU1,UniProtKB:Q6FWW0,UniProtKB:Q6FWY1,UniProtKB:Q6FXL6,Q6FXQ9,UniProtKB:Q6FXR3,UniProtKB:Q6FXI6,UniProtKB:Q6FXJ5,UniProtKB:Q6FXE4,UniProtKB:Q6FY54,UniProtKB:Q6FYB3,UniProtKB:Q6FX56";
    var ontologies = "GO:0003677,GO:0000278,GO:0000902,GO:0000988";


    var targetURL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+genes+"&goId="+ontologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";

    res.send(targetURL);
    /*
    var options = {
	host: targetURL,
	port: '80',
	path: '/send_quickgo_webservice',
	method: 'GET',
	headers: {
	    'Content-Type': 'application/json; charset=utf-8',
	    'Content-Length': data.length
	}
    };
    */
    // var req = https.request(/*options*/targetURL, function(res) {
    https.get(/*options*/targetURL, res => {
	var msg = '';	
	res.setEncoding('utf8');
	res.on('data', chunk => {
	    msg += chunk;
	});
	res.on('end', () => {
	    msg = JSON.parse(msg);
	    console.log(msg);
	});
    });
    
    //req.write(data);
    //req.end();
    /*
    var proxyRequest = http.request({
	host: "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+genes1+genes2+"&goId="+ontologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein",
	port: 80,
	method: 'POST',
	path: '/send_quickgo_webservice'
    },function (proxyResponse) {
	proxyResponse.on('data', function (chunk) {
          res.send(chunk);
	});
	
    });
    res.redirect('/');
    */

    //https://stackoverflow.com/questions/19392744/calling-a-web-service-using-nodejs
});

//En cas de page introuvable
app.use(function(req, res, next){
    res.setHeader('Content-Type', 'text/plain');
    res.status(404).send('Page introuvable !');
});


app.on('close', function() { // On écoute l'évènement close
    console.log('Bye bye !');
});

app.listen(8081);

//Node.js est très bas niveau : on récupère l'URL qu'on doit ensuite parser grâce à plusieurs méthodes, pour déterminer le nom de la page réclamée par le visiteur.
