/**
BLASQUIZ Julie
LUCK Romain
MONGY Marc
RAFFAELLI Michele
14/05/2018
*/

var socket = io.connect('http://localhost:8082');

//get html elements in variables
var launchvenn = document.getElementById('launchvenn');
var launchbackGO = document.getElementById('launchbackGO');
var testeur = document.getElementById('testeur');
var hide1 = document.getElementById('hide1');
var hide2 = document.getElementById('hide2');
var hide3 = document.getElementById('hide3');
var menuselect3 = document.getElementById('menuselect3');
var input1 = document.getElementById('input1');
var input2 = document.getElementById('input2');
var input3 = document.getElementById('input3');
var input4 = document.getElementById('GOlist');

//launch functions from variables
var setupListeners = function() {
	launchvenn.addEventListener('click', launchvennf);
	launchbackGO.addEventListener('click', launchbackGOf);
	testeur.addEventListener('click', testeu);
	hide1.addEventListener('click',hidef1);
	hide2.addEventListener('click',hidef2);
	hide3.addEventListener('click',hidef3);
	menuselect3.addEventListener('change',changef);
	input1.addEventListener('change',openFile);
	input2.addEventListener('change',openFile2);
	input3.addEventListener('change',openFile3);
	input4.addEventListener('change',openFile4);
}
window.addEventListener('load', setupListeners);

function loadServerFile(filePath) {
    var result = null;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", filePath, false);
    xmlhttp.send();
    if (xmlhttp.status==200) {
	result = xmlhttp.responseText;
    }
    return result;
}

//test button
var testeu = function(){
	alert(dictGO.get('GO:0016491'));
}

var hidef = function(id){
	var x = document.getElementById(id);
	if (x.style.display === "none") {
		x.style.display = "block";
	}
	else {
		x.style.display = "none";
}}

//Hide or show a block in html
var hidef1 = function() {
    hidef("importtest");
}
var hidef2 = function() {
    hidef("back_hider");
}
var hidef3 = function() {
    hidef("venn_1");
}

// calcul factoriel of a number
var fact = function(nb){
	var tot = 1;
	for(var i=1; i<=nb; i++){
		tot*=i;
	}
	return tot;
}

//calcul nomber of combinaisons
var nbcombi = function(n,k){
	if(n>=k){return;}
	var ncomb = fact(n)/(fact(k)*fact(n-k));
	return ncomb;
}

//Create an array with each combinaison of p in n elements
var Cnp = function(n,p, l=null, res=null){
	if(l == null){l=[];}
	if(res == null){res=[];}
	if(p==0){
		res.push(l);
		return;
	}
	if(n==0){return;}
	var l1=Array.from(l);
	l1.push(n);
	Cnp(n-1, p-1, l1, res);
	Cnp(n-1, p, l, res);
	return res;
}

//return a tab with all combinaisons with number of files as input
var classes = function(nbtab){
	var tab = [];
	for(var i=1; i<nbtab+1; i++){
		var tmp = Cnp(nbtab,i);
		tab = tab.concat(tmp);
	}
	return tab;
}


//change background color when index is changed
var changef = function(){
	var classes = ["sp1","sp2","sp3","sp1-2","sp2-3","sp1-3","sp1-2-3"];
	var index = document.menuform3.menuselect3.selectedIndex;
	for (var i = 0 ; i<classes.length ; i++){
		var width = document.getElementsByClassName(classes[i]);
		for (var j=0 ; j<width.length ; j++){
		width[j].style.backgroundColor = "white";
	}}
	var width = document.getElementsByClassName(classes[index]);
	for (var i=0 ; i<width.length ; i++){
		width[i].style.backgroundColor = "#aaffaa";
	}
}

//push first element of array to the end
var pushleft = function(tab){
var tmp = tab[0];
tab.splice(0,1);
tab.push(tmp);
}

//delarray removes all duplicated elements - source: https://www.unicoda.com/?p=579
var delarray = function(array) {
    var len = array.length;
    var out = [];
    var obj = {};
    for (var i = 0; i < len; i++) {
	obj[array[i]] = 0;
    }
    var j;
    for (j in obj) {
	out.push(j);
    }
    return out;
}

//return an array with specie names
var filenames = function(){
	var tabsp = [];
	var tabtmp = [];
	for (var i=0;i<3;i++){
		tabtmp.push(document.getElementById('input'+String(i+1)).value);
		var tmp = tabtmp[i].split("\\");
		tmp = tmp[tmp.length-1].split(".");
		tabtmp[i]=tmp[0];
	}
	for(var i=0; i<tabtmp.length; i++){
		tabsp.push('(from '+tabtmp[0]+'): '+tabtmp[0]);
		tabsp.push('(from '+tabtmp[0]+'): '+tabtmp[0]+", "+tabtmp[1]);
		tabsp.push('(from '+tabtmp[0]+'): '+tabtmp[0]+", "+tabtmp[2]);
		tabsp.push('(from '+tabtmp[0]+'): '+tabtmp[0]+", "+tabtmp[1]+", "+tabtmp[2]);
		pushleft(tabtmp);
	}
	return tabsp;
}

var filenames2 = function(){
	var tabsp = [];
	for (var i=0;i<3;i++){
		tabsp.push(document.getElementById('input'+String(i+1)).value);
		var tmp = tabsp[i].split("\\");
		tmp = tmp[tmp.length-1].split(".");
		tabsp[i]=tmp[0];
	}
	tabsp.push(tabsp[0]+"+"+tabsp[1]);
	tabsp.push(tabsp[1]+"+"+tabsp[2]);
	tabsp.push(tabsp[0]+"+"+tabsp[2]);
	tabsp.push(tabsp[0]+"+"+tabsp[1]+"+"+tabsp[2]);
	return tabsp;
}

//Put specie names in the lists
var specielist = function(){
	var tabsp = filenames();
	var tabsp2 = filenames2();
	d3.selectAll(".menusp").remove();
	var add1 = d3.select("#menuselect1");
	var add2 = d3.select("#menuselect2");
	var add3 = d3.select("#menuselect3");
	for (var i=0; i<tabsp.length; i++){
		add1.append("option").attr("class", "menusp").text(tabsp[i]);
		add2.append("option").attr("class", "menusp").text(tabsp[i]);
	}
	for (var i=0; i<7; i++){
		add3.append("option").attr("class", "menusp").text(tabsp2[i]);
	}
}

var launchbackGOf = function(){
launchbackf("quickGO");
}

//send data to david
function launchbackf(dtb) {
    //var sp1 = document.menuform1.menuselect1.selectedIndex;
    //var sp2 = document.menuform2.menuselect2.selectedIndex;
    var genes1 = elem("menuselect1");
    var genes2 = elem("menuselect2");
    if (genes1.length == 0){
    alert("Error: group 1 is empty");
    }
    else if (genes1.length > 500){
    alert("Error in group 1: QuickGO cannot take more than 500 genes.");
    }
    else if (genes2.length == 0){
    alert("Error: group 2 is empty");
    }
    else if (genes2.length > 500){
    alert("Error in group 2: QuickGO cannot take more than 500 genes.");
    }
    else if (dtb == "quickGO"){
    sendquickgo(genes1,genes2);
    }
}

var elem = function(Idlist){
	var list = document.getElementById(Idlist);
	var genes = [];
	for(var i=0; i<list.length; i++){
		if(list.options[i].selected){
			var sp = "sp"+String(1+Math.trunc(i/4));
			genes = genes.concat(tablevenn[sp][i%4]);
		}
	}
	return genes;
}

//Parse the file data when uploading
var parsedata = function(text){
	var dataimport = text.split(["\n"]);
	for(var i=0;i<dataimport.length;i++){
			var tmp = dataimport[i].split([',']);
			dataimport[i] = tmp;
}
return dataimport;
}

function extractingFromJSONstring(groupe, body){
	var result = "";
	var object = JSON.parse(body);
	var genes = object.results;
	for(var geneIndex = 0; geneIndex<genes.length; geneIndex++){
		var gene = genes[geneIndex];
		var UniProtID = gene.geneProductId;
		var slimmedGO = gene.slimmedIds[0];
		result = result + '{"Liste":'+groupe+',"UniProtID":"'+UniProtID+'","SlimmedGO":"'+slimmedGO+'"},';
	}
	return result;
}

function parsingJSON(rawData,N){
	var data = JSON.parse(rawData);
	var listeGenesOntologiesPairs = [];
	var nombreElementsGroupe1 = 0;
	var nombreElementsGroupe2 = 0;
	for(var i = 0; i<data.length; i++){
	if(data[i].Liste == 1){
		nombreElementsGroupe1++;
	}
	if(data[i].Liste == 2){
		nombreElementsGroupe2++;
	}
	}
	var listeGO = [];
	for(var i = 0; i<data.length; i++){
		listeGO.push(data[i].SlimmedGO);
	}
	var uniqueListeGO = delarray(listeGO);
	var JSONstring = "[";
	var jsonElement;
	for(var j = 0; j<uniqueListeGO.length; j++){
		var uniprotGroupe1 = [];
		var uniprotGroupe2 = [];
		for(var i = 0; i<data.length; i++){
			if(data[i].SlimmedGO == uniqueListeGO[j] && data[i].Liste == 1){
				uniprotGroupe1.push('" '+data[i].UniProtID+'"');
				}
				if(data[i].SlimmedGO == uniqueListeGO[j] && data[i].Liste == 2){
				uniprotGroupe2.push('" '+data[i].UniProtID+'"');
			}
		}
		var uniqueUniprotGroupe1 = delarray(uniprotGroupe1);
		var uniqueUniprotGroupe2 = delarray(uniprotGroupe2);
		var uniqueUniprotGroupe3 = [];
		for(var i=0; i<uniqueUniprotGroupe1.length; i++){
			for(var k=0; k<uniqueUniprotGroupe2.length; k++){
				if(uniqueUniprotGroupe1[i] === uniqueUniprotGroupe2[k]){
					uniqueUniprotGroupe3.push(uniqueUniprotGroupe1[i]);
					break;
			}}}
		JSONstring = JSONstring+'{"Annot":"'+uniqueListeGO[j]+'","1":'+uniqueUniprotGroupe1.length+',"2":'+uniqueUniprotGroupe3.length+',"3":'+uniqueUniprotGroupe2.length+',"N":'+N+',"geneID1":['+uniqueUniprotGroupe1+'],"geneIDCommon":['+uniqueUniprotGroupe3+'],"geneID2":['+uniqueUniprotGroupe2+']},';
		}
	JSONstring = JSONstring.substr(0, JSONstring.length - 1)+ ']';
	return JSONstring;
}

//parse string data as json
var strtojson = function(databack){
var databacktmp = [];
for (var i=1; i<databack.length; i++){
	var dictmp = {};
	for (var j=0; j<databack[i].length; j++){
		dictmp[databack[0][j]]=databack[i][j];
	}
	databacktmp.push(dictmp);
}
return databacktmp;
}

var dictGO = new Map();
var parseGO = function(GOannot){
	var newGO = '';
	var splitGO = GOannot.split('\n');
	for(var i=0; i<splitGO.length; i++){
		var keyelem = splitGO[i].split(',');
		dictGO.set(keyelem[0],keyelem[1]);
		newGO+=keyelem[0]+',';
	}
	newGO = newGO.substring(0,newGO.length-1);
	return newGO;
}

//open the input files
var dataimport1 = 0;
var openFile = function(event) {
	var input = event.target;
	var reader = new FileReader();
	reader.onload = function(){
		var text = reader.result;
		dataimport1 = parsedata(text, dataimport1);
		}
	reader.readAsText(input.files[0]);
};

var dataimport2 = 0;
var openFile2 = function(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var text = reader.result;
        dataimport2 = parsedata(text);
        }
    reader.readAsText(input.files[0]);
};

var dataimport3 = 0;
var openFile3 = function(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var text = reader.result;
        dataimport3 = parsedata(text);
        }
    reader.readAsText(input.files[0]);
};

var GOlist = loadServerFile('/textfiles/defaultGOannot.txt');
GOlist = parseGO(GOlist);
var openFile4 = function(event) {
	var input = event.target;
	var reader = new FileReader();
	reader.onload = function(){
		GOlist = reader.result;
		GOlist = parseGO(GOlist);
		}
	reader.readAsText(input.files[0]);
};

//create array with groups and create table
var tablevenn = [];
var parseentry = function(){
var classnames = ["sp1","sp2","sp3","sp1-2","sp2-3","sp1-3","sp1-2-3"]; // later classes()
var table = {"sp1":[[],[],[],[]],"sp2":[[],[],[],[]],"sp3":[[],[],[],[]]};
//for(var i=0; i<classnames.length; i++){table.push([]);}
var cycle = [dataimport1,dataimport2,dataimport3];
//var dic = {5:[3,1,2],6:[4,2,3],7:[5,1,3],10:[3,1,3],11:[4,1,2],12:[5,2,3]}
var nbc = [0,1,2];
var cn = 0;
var tabsp = filenames2();
d3.selectAll('.tablegenes').remove();

//loop for each file
for (var n=0;n<cycle.length;n++){
//create the table
	var line = d3.select("#importtest").append("table").attr("class", "tablegenes").attr("id","tablegenes"+String(n+1));
	line.append("tr").attr("id","tablehead"+String(n+1)).append("th").attr("colspan","3").text(tabsp[n]);

//loop reading every element of a file
for (var i=0; i<cycle[0].length-1;i++){
    var line2 = line.append("tr");
    for (var j=0; j<3; j++){
    
    //add the content of files in the charts with uniprot link
    if (cycle[0][i][j] !== 'NA'){
    line2.append("td").append("a").attr("href", "http://www.uniprot.org/uniprot/" + cycle[0][i][j]).text(cycle[0][i][j]).attr("target","_blank");
    }
    else {
    line2.append("td").text(cycle[0][i][j]);
    }}
    
    //detect category and append table
    line2.attr("class","sp"+String(nbc[0]+1));

    //check table +1
    for (var j=0; j<cycle[1].length;j++){
        if ((cycle[0][i][nbc[1]] === cycle[1][j][nbc[1]])){
            cn+=5;
            break;
        }}
    //check table +2
    for (var j=0; j<cycle[2].length;j++){
        if ((cycle[0][i][nbc[2]] === cycle[2][j][nbc[2]])){
            cn+=10;
            break;
        }}
        
		if (cn === 15){
			table.sp1[3].push(cycle[0][i][0]);
			table.sp2[3].push(cycle[0][i][1]);
			table.sp3[3].push(cycle[0][i][2]);
			line2.attr("class","sp1-2-3");
		}
		else if(cn == 0){
			if(n==0){table.sp1[0].push(cycle[0][i][n]);}
			if(n==1){table.sp2[0].push(cycle[0][i][n]);}
			if(n==2){table.sp3[0].push(cycle[0][i][n]);}
		}
		
		else{
		if (n == 0 && cn === 5){
			table.sp1[1].push(cycle[0][i][0]);
			table.sp2[1].push(cycle[0][i][1]);
			line2.attr("class","sp1-2");
		}
		if (n == 1 && cn === 5){
			table.sp2[2].push(cycle[0][i][1]);
			table.sp3[2].push(cycle[0][i][2]);
			line2.attr("class","sp2-3");
		}
		if (n == 2 && cn === 5){
			table.sp1[2].push(cycle[0][i][0]);
			table.sp3[1].push(cycle[0][i][2]);
			line2.attr("class","sp1-3");
		}
		
		if (n == 0 && cn === 10){
			table.sp1[2].push(cycle[0][i][0]);
			table.sp3[1].push(cycle[0][i][2]);
			line2.attr("class","sp1-3");
		}
		if (n == 1 && cn === 10){
			table.sp1[1].push(cycle[0][i][0]);
			table.sp2[1].push(cycle[0][i][1]);
			line2.attr("class","sp1-2");
		}
		if (n == 2 && cn === 10){
			table.sp2[2].push(cycle[0][i][1]);
			table.sp3[2].push(cycle[0][i][2]);
			line2.attr("class","sp2-3");
		}}
    
    
    /*
    //as dict
    else {
    table[dic[cn+nbc][0]].push(cycle[0][i][dic[cn+nbc[0]][1]]);
    table[dic[cn+nbc][0]].push(cycle[0][i][dic[cn+nbc[0]][2]]);
    line2.attr("class","sp1-3");
    }*/
    
    cn=0;
}
pushleft(cycle);
pushleft(nbc);
}
for(var i=0; i<4; i++){
table.sp1[i] = delarray(table.sp1[i]);
table.sp1[i].sort;
table.sp2[i] = delarray(table.sp2[i]);
table.sp2[i].sort;
table.sp3[i] = delarray(table.sp3[i]);
table.sp3[i].sort;
}
//for (var i=0;i<table.length;i++){table[i] = delarray(table[i]);}
//for(var i=0; i<7; i++){table[i].sort;}
return table;
}

//when the launch button is pressed
var launchvennf = function(){
specielist();
var show = document.getElementById("venndata");
show.style.display = "block";
tablevenn = parseentry();
diagram(tablevenn);
}

//calcul and show the venn diagram from imported data
var diagram = function(tablevenn){
var spname = filenames();
for(var i=0; i<spname.length; i+=4){
	var newsp = spname[i].split(':');
	spname[i] = newsp[1];
}
var classnames = ["sp1","sp2","sp3","sp1-2","sp2-3","sp1-3","sp1-2-3"]
var numbers = [];
for(var i=0; i<classnames.length; i++){
	var sp = document.getElementsByClassName(classnames[i]);
	numbers.push(0);
	for(var j=0; j<sp.length; j++){numbers[i]+=1;}
}
var venndata = [spname[0]+','+String(tablevenn.sp1[0]),spname[4]+','+String(tablevenn.sp2[0]),spname[8]+','+String(tablevenn.sp3[0]),spname[0]+','+String(tablevenn.sp1[1])+"\n\n"+spname[4]+','+String(tablevenn.sp2[1]),spname[4]+','+String(tablevenn.sp2[2])+"\n\n"+spname[8]+','+String(tablevenn.sp3[2]),spname[0]+','+String(tablevenn.sp1[2])+"\n\n"+spname[8]+','+String(tablevenn.sp3[1]),spname[0]+','+String(tablevenn.sp1[3])+"\n\n"+spname[4]+','+String(tablevenn.sp2[3])+"\n\n"+spname[8]+','+String(tablevenn.sp3[3])];

var sets = [
    {sets:["sp1"], figure: venndata[0], label: spname[0], size: 50, number: numbers[0]},
    {sets:["sp2"], figure: venndata[1], label: spname[4], size: 50, number: numbers[1]},
    {sets:["sp3"], figure: venndata[2], label: spname[8], size: 50, number: numbers[2]},
    {sets: ["sp1", "sp2"], figure: venndata[3], label: "", size: 20, number: numbers[3]/2},
    {sets: ["sp2", "sp3"], figure: venndata[4], label: "", size: 20, number: numbers[4]/2},
    {sets: ["sp1", "sp3"], figure: venndata[5], label: "", size: 20, number: numbers[5]/2},
    {sets: ["sp1", "sp2", "sp3"], figure: venndata[6], label: "", size: 5, number: numbers[6]/3}
    ];

var chart = venn.VennDiagram()
    .width(500)
    .height(400)

var div = d3.select("#venn_diagram").datum(sets).call(chart);
    div.selectAll("text").style("fill", "white");
    div.selectAll(".venn-circle path")
    	.style("fill-opacity", .8)
    	.style("stroke-width", 1)
    	.style("stroke-opacity", 1)
    	.style("stroke", "fff");

d3.selectAll('.venntooltip').remove();
var tooltip = d3.select("#venn_value").append("div")
    .attr("class", "venntooltip");

div.selectAll("g")
    .on("mouseover", function(d, i) {
    // sort all the areas relative to the current item
    venn.sortAreas(div, d);

    // Display a tooltip with the current size
    tooltip.transition().duration(40).style("opacity", 1);
    tooltip.text("number of up-regulated genes: " + d.number);

    //highlight the current path
    var selection = d3.select(this).transition("tooltip").duration(400);
    selection.select("path")
        .style("stroke-width", 3)
        .style("stroke-opacity", 1);
    })

    .on("mousemove", function() {
        tooltip.style("left", (d3.event.pageX) + "px")
            .style("top", (d3.event.pageY - 28) + "px");
    })

    .on("mouseout", function(d, i) {
        tooltip.transition().duration(1000).style("opacity", 0);
        var selection = d3.select(this).transition("tooltip").duration(400);
        selection.select("path")
            .style("stroke-width", 3)
            .style("stroke-opacity", 1);
    })

    //show genes ID on the side bar
    .on("click", function(d,i) {
    var fig = String(d.figure);
    fig = fig.split(",");
    for (var i=0; i<fig.length; i++){
    fig[i]="\n"+fig[i];
    }
    d3.select("#infos").text(fig);});
    ;}

var preparesend = function(grp1, grp2, database){
var datasend = database+";";
for (var j=0; j<grp1.length; j++){
	datasend+= grp1[j]+',';
}
datasend+=";";
for (var j=0; j<grp2.length; j++){
	datasend+= grp2[j]+",";
}
return datasend;
}

var sendquickgo = function(grp1,grp2){
d3.select("#backblock").style("display","block");
d3.select('#d3-plot').remove();
d3.select("#loading").text('The process may take several minutes before data are returned : ');
d3.select("#error1").text('');
d3.select("#error2").text('');
d3.select("#loading").append("img").attr("src",'images/ajax-loader.gif').attr('id',"Logo").attr('align','center');
var datasend = preparesend(grp1, grp2, "quickGO");
datasend+=";"+GOlist;
socket.emit("message", datasend);
}

socket.on('message', function(message) {
	if("quickGOdata" == "quickGOdata"){
		d3.select("#loading").text('');
		d3.select('#Logo').remove();
		if(message.match("  ")){
			var tmptab=message.split("  ");
			databack1 = tmptab[0];
			var N1 = databack1.split(':');
			N1 = N1[1].split(',').length;
			databack2 = tmptab[1];
			var N2 = databack2.split(':');
			N2 = N2[1].split(',').length;
			var N=N1+N2
			databack1 = extractingFromJSONstring(1,databack1);
			if(databack1.substring(28,30) == "[]"){
				d3.select('#error1').text("No result for group 1");
			}
			databack2 = extractingFromJSONstring(2,databack2);
			if(databack2.substring(28,30) == "[]"){
				d3.select('#error2').text("No result for group 2");
			}
			if(databack1.substring(28,30) !== "[]" && databack2.substring(28,30) !== "[]"){
				var databack = "["+databack1+databack2;
				databack = databack.substring(0,databack.length-1);
				databack+="]";
				databack = parsingJSON(databack,N);
				databack=JSON.parse(databack);
				backdiagram(databack);
			}
		}
		else{
		d3.select('#error1').text("error returned: "+message);
		}
	}
});

var backdiagram = function(data){
var margin = {top: 50, right: 50, bottom: 10, left: 400},
    width = 950 - margin.left - margin.right,
    height = 50*data.length;

var y = d3.scale.ordinal()
    .rangeRoundBands([0, height], .3);

var x = d3.scale.linear()
    .rangeRound([0, width]);

var color = d3.scale.ordinal()
    .range(["#c7001e", "#cccccc", "#92c6db"]);

var xAxis = d3.svg.axis()
    .scale(x)
    .orient("top");

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left")

var svg = d3.select("#figure").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .attr("id", "d3-plot")
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  color.domain(["Group 1", "Common group", "Group 2"]);

  data.forEach(function(d) {
    // calc percentages
    d["Group 1"] = +d[1]*100/d.N;
    d["Common group"] = +d[2]*100/d.N;
    d["Group 2"] = +d[3]*100/d.N;

    var x0 = -1*(d["Common group"]/2+d["Group 1"]);
    var idx = 0;
    d.boxes = color.domain().map(function(name) { return {name: name, x0: x0, x1: x0 += +d[name], N: +d.N, n: +d[idx += 1]}; });
  });

  var min_val = d3.min(data, function(d) {
          return d.boxes["0"].x0;
          });

  var max_val = d3.max(data, function(d) {
          return d.boxes["2"].x1;
          });

  x.domain([min_val, max_val]).nice();
  y.domain(data.map(function(d) { return d.Annot+' '+dictGO.get(d.Annot); }));

  svg.append("g")
      .attr("class", "y axis")
      .attr("fill","blue")
      .call(yAxis);

  var vakken = svg.selectAll(".Annot")
      .data(data)
      .enter().append("g")
      .attr("class", "bar")
      .attr("transform", function(d) { return "translate(0," + y(d.Annot+' '+dictGO.get(d.Annot)) +")"; });

  var bars = vakken.selectAll("rect")
      .data(function(d) { return d.boxes; })
      .enter().append("g").attr("class", "subbar");

  bars.append("rect")
      .attr("height", y.rangeBand())
      .attr("x", function(d) { return x(d.x0); })
      .attr("width", function(d) { return x(d.x1) - x(d.x0); })
      .style("fill", function(d) { return color(d.name); });

  bars.append("text")
      .attr("x", function(d) { return x(d.x0); })
      .attr("y", y.rangeBand()/2)
      .attr("dy", "0.5em")
      .attr("dx", "0.5em")
      .style("font" ,"10px sans-serif")
      .style("text-anchor", "begin")
      .text(function(d) { return d.n });

  vakken.insert("rect",":first-child")
      .attr("height", y.rangeBand())
      .attr("x", "1")
      .attr("width", width)
      .attr("fill-opacity", "0.5")
      .style("fill", "#F5F5F5")
      .attr("class", function(d,index) { return index%2==0 ? "even" : "uneven"; });

  svg.append("g")
      .attr("class", "y axis")
      .append("line")
      .attr("x1", x(0))
      .attr("x2", x(0))
      .attr("y2", height);

  var startp = svg.append("g").attr("class", "legendbox").attr("id", "mylegendbox");
  var legend_tabs = [120, 240, 360];
var legend = startp.selectAll(".legend")
      .data(color.domain().slice())
      .enter().append("g")
      .attr("class", "legend")
      .attr("transform", function(d, i) { return "translate(" + legend_tabs[i] + ",-45)"; });
  
  legend.append("rect")
      .attr("x", 0)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill", color);

  legend.append("text")
      .attr("x", 22)
      .attr("y", 9)
      .attr("dy", ".35em")
      .style("text-anchor", "begin")
      .style("font" ,"10px sans-serif")
      .text(function(d) { return d; });

  d3.selectAll(".axis path")
      .style("fill", "none")
      .style("stroke", "#000")
      .style("shape-rendering", "crispEdges");

  d3.selectAll(".axis line")
      .style("fill", "none")
      .style("stroke", "#000")
      .style("shape-rendering", "crispEdges");

  //var movesize = width/2 - startp.node().getBBox().width/2;
  //d3.selectAll(".legendbox").attr("transform", "translate(" + movesize  + ",0)");

//Diminuer opacite de la barre ou se trouve la souris
  var interaction = d3.selectAll(".bar")
    .on("mouseover", function(d) { d3.select(this).attr("fill-opacity", "0.5");})
    .on("mouseout", function(d) { d3.select(this).attr("fill-opacity", "1");});

//Afficher infos bios supplementaires lors d'un click sur une des barres de l'histo
  var interaction = d3.selectAll(".bar")
    .on("click", function(d,i) { d3.select("#infos").text('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'+d.Annot +'\n\n'+"Group 1, " + d[1] + " ID : "+'\n\n' + d.geneID1 +'\n\n'+"Common group, " + d[2] + " ID : "+'\n\n'+ d.geneIDCommon + '\n\n'+"Group 2, "  + d[3] + " ID : "+'\n\n'+ d.geneID2);});

//Diminuer l'opacite des legendes et de l'histo au passage de la souris sur les legendes
  var legend = startp.selectAll(".legend")
    .on("mouseover", function(d) { interaction.attr("fill-opacity", "0.5"),d3.select(this).attr("fill-opacity", "0.5");})
    .on("mouseout", function(d) { interaction.attr("fill-opacity", "1"),d3.select(this).attr("fill-opacity", "1");});

	var linkgo = d3.selectAll('.tick')
		.on('click',function(d){
			var GOterm = d.split(' ');
			window.open('https://www.ebi.ac.uk/QuickGO/term/'+GOterm[0]);
		});
}






