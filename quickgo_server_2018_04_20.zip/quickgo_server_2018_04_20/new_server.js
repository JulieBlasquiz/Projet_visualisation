'use strict' //Toujours l'utiliser. Plus d'infos ici: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Strict_mode

/*----------------------------------Fonctions maison--------------------------------------*/

function convertQuickGO(fs, filePath, targetList){
    var fileString = fs.readFileSync(filePath, "UTF-8");
    fileString = fileString.substring(0,fileString.length-1);
    var conversionToList = fileString.split(",\n");
    for(var i = 0; i<conversionToList.length; i++){
	targetList.push(conversionToList[i]);
    }
    var quickGOstring = targetList.join(',');
    quickGOstring = quickGOstring.substring(0,quickGOstring.length-1);
    return quickGOstring;
}


/*----------------------------------NodeJS--------------------------------------*/

// ---------------- Modules de base, indispensables pour à peu près tout

const url = require('url'); //Pour utilisation d'URLs
const fs = require('fs'); //Pour transferts de fichiers
const bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
const urlencodedParser = bodyParser.urlencoded({ extended: false });


// ---------------- Utilisation d'Express

//var server = http.createServer(); //Pas besoin, créé automatiquement grâce à express
const express = require('express'); //Framework de design de serveurs nodejs
const app = express();
app.use(express.static(__dirname)); //Utilisation du répertoire par défaut pour les fichiers annexes
const multer = require('multer'); //Gestion des transferts de fichiers - Nécessite Express
//let upload = multer({storage: multer.memoryStorage()});
const upload = multer({ dest: 'uploads/' });

var querystring = require('querystring');
var session = require('cookie-session'); // Charge le middleware de sessions
app.use(session({secret: 'quickgo'})); // Utilisation d'un système de sessions


// ---------------- Modules destinés aux requêtes externes. On n'utilise que request car simple et rapide d'utilisation. Les modules http et https obligent à mettre les mains dans le cambouis.

const http = require('http');
const https = require('https');
//https.globalAgent.options.secureProtocol = 'SSLv3_method';
//https.globalAgent.options.secureProtocol = 'TLSv1_method';
const csp = require('helmet-csp'); // Gestion de la Content-Security-Policy. Utilisé avec les modules http et https - voir: https://ponyfoo.com/articles/content-security-policy-in-express-apps et https://helmetjs.github.io/docs/csp/
app.use(csp({
    directives: {
	defaultSrc: ["'self'"], //"data:", '"unsafe-inline"','"unsafe-eval"'],
	scriptSrc: ["'self'"], //'"unsafe-inline"','"unsafe-eval"'],
	connectSrc: ["'self'", 'ebi.ac.uk'],
	imgSrc: ["'self'"]
    }
}));
const request = require('request'); //Utilisé ici
const rp = require('request-promise');


// ---------------- Modules envisagés, mais non utilisés en raison d'une documentation trop minimaliste. Peut-être pour plus tard...

var quickgo = require('bionode-quickgo');
var obo = require('bionode-obo');


// ---------------- Script serveur

// autorisation du script d3js
app.use(function(req, res, next) {
    res.setHeader("Content-Security-Policy", "script-src 'self' http://cdnjs.cloudflare.com/ajax/libs/d3/3.4.13/d3.min.js");
    return next();
});


/* S'il n'y a pas de liste de gènes dans la session, on en crée une vide sous forme d'array avant la suite */
app.use(function(req, res, next){
    console.log("Creating lists");
    if (typeof(req.session.genesList1) == 'undefined') {
        req.session.genesList1 = [];
    }
    if (typeof(req.session.genesList2) == 'undefined') {
        req.session.genesList2 = [];
    }
    
    if (typeof(req.session.ontologiesList) == 'undefined') {
	req.session.ontologiesList = [];
    }

    if (typeof(req.session.data) == 'undefined') {
	req.session.data = [];
    }
    //console.log(req.session);
    //console.log(req.body);
    next();
});


/* On affiche la liste de gènes, la liste d'ontologies et le formulaire */
app.get('/', function(req, res) {
    console.log("Rendering HTML page");
    res.render('new_try.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
});


// On envoie le script client
app.post('/client.js', function(req, res) {
    console.log("Posting client JS script");
    script = fs.readFileSync("client.js", "utf8");
    res.write(script);
    res.render('new_try.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
    res.redirect('/');
});


// On charge les fichiers et on met le contenu dans une requête
app.post('/load_data', upload.array('file', 3), function(req, res, next) {
    console.log("Loading Files");
    //console.log(req.files);
    var stringGenes1 = convertQuickGO(fs, req.files[0].path, req.session.genesList1);
    console.log(stringGenes1);
    var stringGenes2 = convertQuickGO(fs, req.files[1].path, req.session.genesList2);
    console.log(stringGenes2);
    var stringOntologies = convertQuickGO(fs, req.files[2].path, req.session.ontologiesList);
    console.log(stringOntologies);
    var genes1URL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+stringGenes1+"&goId="+stringOntologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";
    var genes2URL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+stringGenes2+"&goId="+stringOntologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";

    console.log("Send to QuickGO");
    
    let fileWriteStreamGenes1JSON = fs.createWriteStream(req.files[0].path+'_genes1.json');
    let fileWriteStreamGenes2JSON = fs.createWriteStream(req.files[1].path+'_genes2.json');
    
    request.get(genes1URL, (error, response, body) =>{
	//console.log("error: ", error);
	//console.log("statusCode: ", response);
	//console.log(body);
	let genes1JSON = JSON.parse(body);
	console.log(genes1JSON);
    })
	.pipe(fileWriteStreamGenes1JSON);

    request.get(genes2URL, (error, response, body) =>{
	//console.log("error: ", error);
	//console.log("statusCode: ", response);
	//console.log(body);
	let genes2JSON = JSON.parse(body);
	console.log(genes2JSON);
    })
	.pipe(fileWriteStreamGenes2JSON);

    let fileReadStreamGenes1JSON = fs.createReadStream(req.files[0].path+'_genes1.json');
    let fileReadStreamGenes2JSON = fs.createReadStream(req.files[1].path+'_genes2.json');
    res.setHeader('Content-Type', 'text/plain');
    res.send("Finished, your data is in the uploads directory");
    res.end(fs.readFileSync(req.files[0].path+'_genes1.json', "UTF-8")+"\n\n"+fs.readFileSync(req.files[1].path+'_genes2.json', "UTF-8"));
});

/*
app.get("/", function (req, res, next) {
    res.setHeader('Content-Type', 'text/html');
    // Render the 'webLocation' obtained from the middleware.
    //console.log(req.webLocation);
    res.send(req.webLocation);
    next();
});
*/




// Process application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: true}))

// Process application/json
app.use(bodyParser.json());

app.post('/client.js', function(req, res){  
//now req.body will be populated with the object you sent
console.log(req.body); //prints 
});


//En cas de page introuvable
app.get(function(req, res){
    res.setHeader('Content-Type', 'text/plain');
    console.log("Error detected, redirecting to form");
    res.status(404).send('Page introuvable !');
    res.redirect('/');
});
    
	 
app.on('close', function() { // On écoute l'évènement close
    console.log('Bye bye !');
});

app.listen(8082);

	 
	
