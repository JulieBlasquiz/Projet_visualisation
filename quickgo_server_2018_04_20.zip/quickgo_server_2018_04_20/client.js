/*
function chargerListeGO(event){
    var reader = new FileReader();
    var fileInput = reader.readAsDataURL("./refs/GO_description.tab");
    fileInput.addEventListener('change', function() {
	reader.readAsText(fileInput.files[0]);
	reader.addEventListener('load', function() {
	    //console.log(reader.result);
	    //alert('Contenu du fichier "' + fileInput.files[0].name + '" :\n\n' + reader.result);
	    pipelineGOrefs(reader.result);
	});
    });
}
*/

function loadServerFile(filePath) { //à mettre côté serveur
    var result = null;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", filePath, false);
    xmlhttp.send();
    if (xmlhttp.status==200) {
	result = xmlhttp.responseText;
    }
    return result;
}

function chargerFichierListe1(event){
    var fileInput = document.getElementById('fileGenes_liste_1');
    chargerFichierGenes(fileInput);
}


function chargerFichierListe2(event){
    var fileInput = document.getElementById('fileGenes_liste_2');
    chargerFichierGenes(fileInput);
}


function chargerFichierGenes(fileInput){
    //var fileInput = document.querySelector('#fileGenes');
    fileInput.addEventListener('change', function() {
	var reader = new FileReader();
	reader.readAsText(fileInput.files[0]);
	reader.addEventListener('load', function() {
	    //console.log(reader.result);
	    //alert('Contenu du fichier "' + fileInput.files[0].name + '" :\n\n' + reader.result);
	    var genesList = convertStringReturnToList(reader.result);
	    for(var i = 0; i<genesList.length; i++){
		//genesList.forEach(function(gene, index){
		var newGene = document.createElement("newGene");
		newGene.id = "newGene";
		newGene.value = genesList[i]; //gene;
		newGene.innerHTML = genesList[i]; //gene;
	    }
		//return genesList;
	});
    });
}


function convertStringReturnToList(item){
    var fileToList = item.split("\r\n");
    //console.log(fileToList);
    return fileToList;
}

function convertStringCommaToList(item){
    var fileToList = item.split(",");
    //console.log(fileToList);
    return fileToList;
}

function createDropDownList(){ // à mettre côté serveur
    //var fichierGO = loadServerFile("./refs/GO_description.tab");
    var fichierGO = loadServerFile("./refs/example.tab");
    //var fichierGO = chargerListeGO("./refs/example.tab");
    console.log(fichierGO);
    var GOlist = convertStringReturnToList(fichierGO);
    var HTMLontologiesList = document.getElementById("newListedOntology")
    //for(var i = 0; i<GOlist.size; i++){
    GOlist.forEach(function(ontology, index){
	var listedOntology = document.createElement("option");
	listedOntology.id = "listedOntology";
	//listedOntology.value = GOlist[i];
	//listedOntology.innerHTML = GOlist[i];
	listedOntology.value = ontology;
	listedOntology.innerHTML = ontology;
	HTMLontologiesList.appendChild(listedOntology);
    });
}

/*
function sendGeneList(event){
    var genesList = chargerFichierGenes(event);
    console.log(genesList);
    for(var i = 0; i<genesList.length; i++){
    //genesList.forEach(function(gene, index){
	var newGene = document.createElement("newGene");
	newGene.id = "newGene";
	newGene.value = gene;
	newGene.innerHTML = gene;
	//});
    }
    //return genesList;
}
*/

function setupListeners(){
    //window.addEventListener("load", createDropDownList);
    //createDropDownList();
    window.addEventListener("load", createDropDownList);
    //window.addEventListener("click", sendGeneList);
    window.addEventListener("click", chargerFichierListe1);
    window.addEventListener("click", chargerFichierListe2);
}

//window.addEventListener("load", setupListeners);
