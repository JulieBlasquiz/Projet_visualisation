import sys
sys.path.append('../')
import logging
import traceback as tb
import suds.metrics as metrics
from tests import *
from suds import *
from suds.client import Client
from datetime import datetime
from collections import Counter
from operator import itemgetter
from collections import OrderedDict

#Connexion David :
def connexion_DAVID():
    errors = 0
    setup_logging()
    logging.getLogger('suds.client').setLevel(logging.DEBUG)
    url = 'https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'
    
    # create a service client using the wsdl.
    client = Client(url)
    client.wsdl.services[0].setlocation('https://david-d.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

    #authenticate user email 
    client.service.authenticate('reviewer@reviewer.org')
    setup_logging()
    logging.getLogger('suds.client').setLevel(logging.DEBUG)
    url = 'https://david.ncifcrf.gov/webservice/services/DAVIDWebService?wsdl'

    # create a service client using the wsdl.
    client = Client(url)
    client.wsdl.services[0].setlocation('https://david.ncifcrf.gov/webservice/services/DAVIDWebService.DAVIDWebServiceHttpSoap11Endpoint/')

    #authenticate user email
    client.service.authenticate('julie.blasquiz@etu.u-bordeaux.fr')
    return client

client  = connexion_DAVID()              
print "DAVID connexion established\n"
#add a list
#ListeID = fichier.read()
#fichier.close()
ListeID = sys.stdin.readlines()
#ListeID1 = json.loads(ListeID[0])
#ListeID2 = json.loads(ListeID[1])

liste_fichier_entree = [ListeID]#,ListeID2]

for i in range(len(liste_fichier_entree)):
    ListeID = liste_fichier_entree[i]
    inputIds = ListeID
    idType = 'UNIPROT_ACCESSION'
    listName = 'make_up'
    listType = 0
    print client.service.addList(inputIds, idType, listName, listType)

    categorySting = str(client.service.setCategories('KEGG_PATHWAY'))
    categories=categorySting.split(',')

    #tableReport = client.service.getTableReport()
    #tableRow = len(tableReport)
    #print 'Total table records:',tableRow

print inputIds
print "DAVID webservice ok"

