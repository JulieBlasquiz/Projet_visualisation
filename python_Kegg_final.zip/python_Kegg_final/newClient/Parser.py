# Script permettant de parser le fichier de sortie de David :
from collections import Counter
from operator import itemgetter

tot_annot = 0

liste_annot1 = []
liste_id1 = []
dico_index_annot = {}
dico_yep = {}
liste_value = []
dico_nb_annot = {}

liste_annot_commun = []

liste_fichier_entree = ['list.tableReport1.txt','list.tableReport2.txt']

for a in range(2):
    with open(liste_fichier_entree[a], 'r') as f :
        for line in f :
            liste_annot1.append(line.split(',')[0])
            liste_id1.append(line.split(',')[1])
            tot_annot = tot_annot + 1

        for annotation in set(liste_annot1):
    	    for i,annot in enumerate(liste_annot1):
		    if annot == annotation:
			    dico_index_annot.setdefault(annot, set()).add(i)

        for cle,value in dico_index_annot.iteritems():
	    for v in value:
		    id_gene = liste_id1[v]
		    liste_value.append(id_gene)
	    dico_nb_annot[cle] = len(liste_value)
	    var = '; '.join(j for j in liste_value)
	    dico_yep[cle] = var
	    liste_value = []
	    var = None

    with open(liste_fichier_entree[a], 'w') as f :
        f.write('Annot'+','+'1'+','+'2'+','+'3'+','+'N'+','+'geneID')
        for j in range(len(dico_yep)):
            f.write('\n'+str(dico_yep.keys()[j])+','+str(dico_nb_annot.values()[j])+','+'0'+','+'0'+','+str(tot_annot)+','+str(dico_yep.values()[j]))

print "C'est fait ;)","\n","Toutes les infos sont dans ",liste_fichier_entree[0]," et ",liste_fichier_entree[1]
