'use strict' //Toujours l'utiliser. Plus d'infos ici: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Strict_mode


/*----------------------------------Fonctions maison--------------------------------------*/



function convertQuickGO(fs, filePath, targetList){
    var fileString = fs.readFileSync(filePath, "UTF-8");
    fileString = fileString.substring(0,fileString.length-1);
    var conversionToList = fileString.split(",\n");
    for(var i = 0; i<conversionToList.length; i++){
	targetList.push(conversionToList[i]);
    }
    var quickGOstring = targetList.join(',');
    quickGOstring = quickGOstring.substring(0,quickGOstring.length-1);
    return quickGOstring;
}


function generateDate(){ //générer le fichier json ultime en utilisant la date
    var date = new Date();
    var year = date.getFullYear(); //Get the year as a four digit number (yyyy)
    var month = date.getMonth()+1; //Get the month as a number (0-11)
    var day = date.getDate(); //Get the day as a number (1-31)
    var hour = date.getHours(); //Get the hour (0-23)
    var minute = date.getMinutes(); //Get the minute (0-59)
    var second = date.getSeconds(); //Get the second (0-59)
    var millisecond = date.getMilliseconds(); //Get the millisecond (0-999)
    //getTime() 	Get the time (milliseconds since January 1, 1970)
    //getDay() 	Get the weekday as a number (0-6)
    var stringDate = year+"_"+month+"_"+day+"_"+hour+"_"+minute+"_"+second+"_"+millisecond;
    return stringDate;
}

//voir http://bl.ocks.org/Jverma/887877fc5c2c2d99be10
//https://github.com/d3/d3/wiki


function wait(ms){
    var start = new Date().getTime();
    var end = start;
    while(end < start + ms) {
	end = new Date().getTime();
    }
    //https://stackoverflow.com/questions/14226803/wait-5-seconds-before-executing-next-line
}


function endWriteStream(writeStream, endingCharacter, endingTime){
    //
    setTimeout(function () {
	writeStream.write(endingCharacter);
	
	//writeStream.end(endingCharacter);
	writeStream.on('finish', () => {
	    console.error('All writes are now complete.');
	});
	
    }, endingTime);
}




function writeFinalJSONbeginning(fs, tempWriteStream){
    var result = "[\n";
    console.log(result);
    tempWriteStream.write(result);
    //voir https://stackoverflow.com/questions/30901153/removing-the-last-character-from-file-stream-in-node-js-fs-module


}


function extractingFromJSONstring(fs, JSON, groupe, body, tempWriteStream){
    //console.log("Writing Content, file", groupe);
    var result = "";
    var object = JSON.parse(body);
    var genes = object.results;
 
    for(var geneIndex = 0; geneIndex<genes.length; geneIndex++){
	result = result + "{";
	result = result + '"Liste"'+":"+groupe+",";
	var gene = genes[geneIndex];
	var UniProtID = gene.geneProductId;
	result = result + '"UniProtID"'+":"+'"'+UniProtID+'"'+",";
	var slimmedGO = gene.slimmedIds[0];
	result = result + '"SlimmedGO"'+":"+'"'+slimmedGO+'"';
	result = result + "}";
	result = result + ",\n";
    }
    return result;
}


function requestingWebsite(request, fs, JSON, webSiteURL, requestWriteStream, fileIndex, tempWriteStream, path, date, callback){
    // https://stackoverflow.com/questions/35195725/nodejs-re-calling-function-on-error-callback-is-there-a-non-blocking-way
    var counter = 0;
    var retryTimes = 30;
    var retryDelay = 1000; // en millisecondes

    var fileNumber = fileIndex+1;
    function run(){
	console.log(webSiteURL);
	request.get(webSiteURL, (error, response, body) =>{
	    ++counter;
	    if (error) {
		console.log("error: ", error);
		if (counter >= retryTimes) {
                    // if it fails too many times, just send the error out
                    callback(error);
		} else {
                    // try again after a delay
                    setTimeout(run, retryDelay);
		}
	    }
	    else {
		// success, send the data out
		//console.log("statusCode: ", response);
		//console.log(body);
		//let contentJSON = JSON.parse(body);
		//console.log(contentJSON);
		
		var result = extractingFromJSONstring(fs, JSON, fileNumber, body, tempWriteStream);
		tempWriteStream.write(result, function(err){
		    //writeFinalJSONending(fs, tempWriteStream, path, date);
		});

		/*
		var result = extractingFromJSONstring(fs, JSON, fileNumber, body, tempWriteStream)
		tempWriteStream.write(result);
		*/
		callback(null, response, body);
		
	    }
	}).pipe(requestWriteStream);
    }
    // start our first request
    run();
}

function requestingWebsites(request, fs, JSON, webSiteURLlist, requestWriteStreamList, tempWriteStream, path, date){
    //https://samwize.com/2013/09/01/how-you-can-pass-a-variable-into-callback-function-in-node-dot-js/
    //console.log(webSiteURLlist);

    for(var fileIndex = 0; fileIndex<webSiteURLlist.length; fileIndex++){
	
	requestingWebsite(request, fs, JSON, webSiteURLlist[fileIndex], requestWriteStreamList[fileIndex], fileIndex, tempWriteStream, path, date, function(response){
	    //console.log("INDEX = "+this.fileIndex+", URL = "+webSiteURLlist[this.fileIndex]+", RESPONSE = "+response);
	}.bind({fileIndex: fileIndex}));
    }
}

function writeFinalJSONending(fs, tempWriteStream, path, date){
    //wait(5000);
    //var result = "]";
    //console.log("]");
    //tempWriteStream.write(result);
    setTimeout(function () {
	//endWriteStream(tempWriteStream, "]", 1000); //
	//writeFromTempToFinalJSON(path, date);
	endTempWriteStream(fs, tempWriteStream, 1000, path, date);
    }, 6000);
    //tempWriteStream.end(); //voir https://stackoverflow.com/questions/27769842/write-after-end-error-in-node-js-webserver pour plus d'infos
    //writeFromTempToFinalJSON(path, date);
}


function endTempWriteStream(fs, writeStream, endingTime, path, date){
    
    setTimeout(function () {
	//writeStream.write(endingCharacter);
	cutLastComma(fs, writeStream, "temp", path, date); //c'est la 2ème fois que je fais ce truc (appel d'une fonction d'une fonction d'une fonction) dans un setTimeout. C'est ça, le "callback hell"?
	//writeFromTempToFinalJSON(path, date); 
	/*
	writeStream.end(endingCharacter);
	writeStream.on('finish', () => {
	    console.error('All writes are now complete.');
	});
	*/
    }, endingTime);
}



function cutLastComma(fs, writeStream, filePath, path, date){
    var endingCharacter = ']';
    writeStream.write(endingCharacter, function(err){
	if (err) {
            throw err;
	}
	let cutTempWriteStream = fs.createWriteStream("cutTemp");
	var fileString = fs.readFile(filePath, 'utf8', function(err, data){
	    if (err) {
		throw err;
	    }
	    fileString = data;
	    var fileStringCut = fileString.substr(0, fileString.length - 3)+ '\n]';
	    cutTempWriteStream.write(fileStringCut, function(err){
		if (err) {
		    throw err;
		}
		writeFromTempToFinalJSON(path, date); 
	    });  
	});
    });
    
    //fileString = fileString.substring(0, fileString.length - 2)+ ']';

}


function writeFromTempToFinalJSON(path, date){
    let tempReadStream = fs.createReadStream("cutTemp");
    let finalJSONwriteStream = fs.createWriteStream(path+date+".json");
    console.log("Writing JSON File");
    tempReadStream.pipe(finalJSONwriteStream, function(err){tempReadStream.end();});
    //finalJSONwriteStream.end();
    setTimeout(function () {
	endWriteStream(finalJSONwriteStream, "\n", 8000);
	//écrire mes fonctions de correction de fichier ici
    }, 9000); 
}


function clearTempFile(fs){
    let tempWriteStream = fs.createWriteStream("temp");
    var result = "";
    tempWriteStream.write(result);
    tempWriteStream.end();
}


function generateFinalJSONfile(request, fs, JSON, webSiteURLlist, requestWriteStreamList, path, date){
    let tempWriteStream = fs.createWriteStream("temp");
    writeFinalJSONbeginning(fs, tempWriteStream);
    requestingWebsites(request, fs, JSON, webSiteURLlist, requestWriteStreamList, tempWriteStream, path, date);
    writeFinalJSONending(fs, tempWriteStream, path, date);
    //tempWriteStream.end();
    //writeFromTempToFinalJSON(path, date);
    //clearTempFile(fs);
}


//cleanArray removes all duplicated elements - source: https://www.unicoda.com/?p=579
function cleanArray(array) {
    var len = array.length;
    var out = [];
    var obj = {};
    for (var i = 0; i < len; i++) {
	obj[array[i]] = 0;
    }
    var j;
    for (j in obj) {
	out.push(j);
    }
    return out;
}


function getListeGenes(listeGenesOntologiesPairs){
    var listeGenes = [];
    for(var i = 0; i<listeGenesOntologiesPairs.length; i++){
	listeGenes.push(listeGenesOntologiesPairs[i][0]);
    }
    listeGenes = cleanArray(listeGenes);
    return listeGenes;
}


function getListeOntologies(listeGenesOntologiesPairs){
    var listeOntologies = [];
    for(var i = 0; i<listeGenesOntologiesPairs.length; i++){
	listeOntologies.push(listeGenesOntologiesPairs[i][1]);
    }
    listeOntologies = cleanArray(listeOntologies);
    return listeOntologies;
}




/*----------------------------------NodeJS--------------------------------------*/

// ---------------- Modules de base, indispensables pour à peu près tout

const url = require('url'); //Pour utilisation d'URLs
const fs = require('fs'); //Pour transferts de fichiers
const bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
const urlencodedParser = bodyParser.urlencoded({ extended: false });


// ---------------- Modules destinés aux requêtes externes. On n'utilise que request car simple et rapide d'utilisation. Les modules http et https obligent à mettre les mains dans le cambouis.

const http = require('http');
const https = require('https');
//https.globalAgent.options.secureProtocol = 'SSLv3_method';
//https.globalAgent.options.secureProtocol = 'TLSv1_method';

const request = require('request'); //Utilisé ici
const rp = require('request-promise');


// ---------------- Utilisation d'Express

//var server = http.createServer(); //Pas besoin, créé automatiquement grâce à express
const express = require('express'); //Framework de design de serveurs nodejs
const app = express();
var server = require('http').Server(app);
app.use(express.static(__dirname)); //Utilisation du répertoire par défaut pour les fichiers annexes
const multer = require('multer'); //Gestion des transferts de fichiers - Nécessite Express
//let upload = multer({storage: multer.memoryStorage()});
const upload = multer({ dest: 'uploads/' });

var querystring = require('querystring');
var session = require('cookie-session'); // Charge le middleware de sessions
app.use(session({secret: 'quickgo'})); // Utilisation d'un système de sessions


// --------------socket io

var io = require("socket.io")(server);

// --------------Gestion de la Content-Security-Policy. Utilisé avec les modules http et https - voir: https://ponyfoo.com/articles/content-security-policy-in-express-apps et https://helmetjs.github.io/docs/csp/
const csp = require('helmet-csp'); 
app.use(csp({
    directives: {
	defaultSrc: ["'self'"], //"data:", '"unsafe-inline"','"unsafe-eval"'],
	scriptSrc: ["'self'"], //'"unsafe-inline"','"unsafe-eval"'],
	connectSrc: ["'self'", 'ebi.ac.uk'],
	imgSrc: ["'self'"]
    }
}));


// ---------------- Utilisation de D3JS - finalement non utilisé sur serveur

//const fetch = require('node-fetch');
const d3 = require('d3');
const d3_fetch = require('d3-fetch_tuned_by_2M');
/*
const jsdom = require('jsdom'); //mettre à jour npm et jsdom -> bug sûrement lié
const exposedProperties = ['window', 'navigator', 'document'];
const { JSDOM } = jsdom;
const d = new JSDOM('<!doctype html><html><body></body></html>');
global.window = (d).window;
global.document = (d).window.document;

*/

//Attention: jsdom à eu une nouvelle API -> utiliser l'ancienne au pire
//var jsdom = require("jsdom/lib/old-api.js");
//var jsdom = require("jsdom");
//var document = jsdom.jsdom();
//var svg = d3.select(document.body).append("svg");


//Configuration de Julie
var margin = {top: 50, right: 0, bottom: 10, left: 320},
    width = 800 - margin.left - margin.right,
    height = 2500;

/* d3.v3 seulement
var y = d3.scale.ordinal()
    .rangeRoundBands([0, height], .3);

var x = d3.scale.linear()
    .rangeRound([0, width]);

var color = d3.scale.ordinal()
    .range(["#c7001e", "#cccccc", "#92c6db"])
    .domain(["Group 1", "Common", "Group 2"]);

var xAxis = d3.svg.axis()
    .scale(x)
    .orient("top");

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left")
*/

var y = d3.scaleBand()
    .rangeRound([0, height], .3);

var x = d3.scaleLinear()
    .rangeRound([0, width]);

var color = d3.scaleOrdinal()
    .range(["#c7001e", "#cccccc", "#92c6db"])
    .domain(["Group 1", "Common", "Group 2"]);

var xAxis = d3.axisBottom(x);

var yAxis = d3.axisLeft(y);

//console.log(d3.select(window.document));


// ---------------- Modules envisagés, mais non utilisés en raison d'une documentation trop minimaliste. Peut-être pour plus tard...

var quickgo = require('bionode-quickgo');
var obo = require('bionode-obo');


// ---------------- The rest...

var path = "./uploads/";
var date = generateDate();
clearTempFile(fs);


// ---------------- Script serveur


// autorisation du script d3js
app.use(function(req, res, next) {
    res.setHeader("Content-Security-Policy", "script-src 'self' http://cdnjs.cloudflare.com/ajax/libs/d3/3.4.13/d3.min.js");
    return next();
});

	
/* S'il n'y a pas de liste de gènes dans la session, on en crée une vide sous forme d'array avant la suite */
app.use(function(req, res, next){
    console.log("Creating lists");
    if (typeof(req.session.genesList1) == 'undefined') {
        req.session.genesList1 = [];
    }
    if (typeof(req.session.genesList2) == 'undefined') {
        req.session.genesList2 = [];
    }
    
    if (typeof(req.session.ontologiesList) == 'undefined') {
	req.session.ontologiesList = [];
    }

    if (typeof(req.session.data) == 'undefined') {
	req.session.data = [];
    }
    req.session.genesList1 = []; //s'assurer d'avoir des listes vides
    req.session.genesList2 = [];
    req.session.ontologiesList = [];
    //console.log(req.session);
    //console.log(req.body);
    next();
});


/* On affiche la liste de gènes, la liste d'ontologies et le formulaire */
app.get('/', function(req, res) {
    console.log("Rendering HTML page");
    res.render('new_try.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
});


// On envoie le script client
app.post('/client.js', function(req, res) {
    console.log("Posting client JS script");
    script = fs.readFileSync("client.js", "utf8");
    res.write(script);
    res.render('new_try.ejs', {genesList1: req.session.genesList1, genesList2: req.session.genesList2, ontologiesList: req.session.ontologiesList});
    res.redirect('/');
});


// On charge les fichiers et on met le contenu dans une requête
app.post('/load_data', upload.array('file', 3), function(req, res) {
    console.log("Loading Files");
    //console.log(req.files);
    var stringGenes1 = convertQuickGO(fs, req.files[0].path, req.session.genesList1);
    //console.log(stringGenes1);
    var stringGenes2 = convertQuickGO(fs, req.files[1].path, req.session.genesList2);
    //console.log(stringGenes2);
    var stringOntologies = convertQuickGO(fs, req.files[2].path, req.session.ontologiesList);
    //console.log(stringOntologies);

    var urlList = [];
    var genes1URL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+stringGenes1+"&goId="+stringOntologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";
    //console.log(genes1URL);
    urlList.push(genes1URL);
    var genes2URL = "https://www.ebi.ac.uk/QuickGO/services/annotation/search?geneProductId="+stringGenes2+"&goId="+stringOntologies+"&qualifier=enables&goUsage=slim&goUsageRelationships=is_a&geneProductType=protein";
    //console.log(genes2URL);
    urlList.push(genes2URL);

    var geneFilesWriteStreamsList = [];
    let fileWriteStreamGenes1JSON = fs.createWriteStream(req.files[0].path+'_genes1.json');
    geneFilesWriteStreamsList.push(fileWriteStreamGenes1JSON);
    let fileWriteStreamGenes2JSON = fs.createWriteStream(req.files[1].path+'_genes2.json');
    geneFilesWriteStreamsList.push(fileWriteStreamGenes2JSON);

    console.log("Send to QuickGO");
    
    generateFinalJSONfile(request, fs, JSON, urlList, geneFilesWriteStreamsList, path, date);

    console.log("Using D3JS");

    /*
    //console.log(jsdom.env);
    jsdom.env({ 
	html:'/load_data', // pris sur https://bl.ocks.org/tomgp/c99a699587b5c5465228
	features:{ QuerySelector:true }, //you need query selector for D3 to work
	done:function(errors, window){
	    var figureDom = window.document.querySelector('#figure');
	    //window.d3 = d3.select(window.document); //get d3 into the dom
	    */

    /*
    svg = d3.select(figureDom).append("svg")
	.attr("width", width + margin.left + margin.right)
	.attr("height", height + margin.top + margin.bottom)
	.attr("id", "d3-plot")
	.append("g")
	.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    //console.log(d3.select(window.document).select("#figure").attr("src"));
    
    //console.log(d3_fetch.json);
    */
    /*
    d3_fetch.json(genes1URL, function(error, data) { //genes1JSONfilePath
	if (error) throw error;
	console.log(data);
	var groupe1 = [];
	extractFromD3jsonData(data, groupe1);
	console.log(groupe1);
	var listeGenesGroupe1 = getListeGenes(groupe1);
	var listeOntologiesGroupe1 = getListeOntologies(groupe1);
	
	x.domain(data.map(function(d) { return d.area; }));
	y.domain([0, d3.max(data, function(d) { return d.value; })]);
    })
    
    d3_fetch.json(genes2URL, function(error, data) { //genes2JSONfilePath
	if (error) throw error;
	console.log(data);
	var groupe2 = [];
	extractFromD3jsonData(data, groupe2);
	console.log(groupe2);
	var listeGenesGroupe2 = getListeGenes(groupe2);
	var listeOntologiesGroupe2 = getListeOntologies(groupe2);
	
	x.domain(data.map(function(d) { return d.area; }));
	y.domain([0, d3.max(data, function(d) { return d.value; })]);
    })
//})
	//})
    */
    //res.setHeader('Content-Type', 'text/plain');
    //res.send("Finished, your data is in the uploads directory");    
    res.redirect('/');
});

/*
app.get("/", function (req, res, next) {
    res.setHeader('Content-Type', 'text/html');
    // Render the 'webLocation' obtained from the middleware.
    //console.log(req.webLocation);
    res.send(req.webLocation);
    next();
});
*/


// Process application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: true}))

// Process application/json
app.use(bodyParser.json());

app.post('/client.js', function(req, res){  
//now req.body will be populated with the object you sent
console.log(req.body); //prints 
});



//En cas de page introuvable
app.get(function(req, res){
    res.setHeader('Content-Type', 'text/plain');
    console.log("Error detected, redirecting to form");
    res.status(404).send('Page introuvable !');
    res.redirect('/');
});
    
	 
app.on('close', function() { // On écoute l'évènement close
    console.log('Bye bye !');
});

//Partie python de Romain
// Quand un client se connecte, on le note dans la console
io.sockets.on('connection', function (socket) {
    socket.emit("message", 'Un client est connecté !');
    console.log("connexion sur le server");
    
    // Quand le serveur reçoit un signal de type "message" du client    
    socket.on('message', function (message) {
        console.log('Un client me parle ! Il me dit : ' + message);
        
        // launch python script
        var spawn = require('child_process').spawn,
	py    = spawn('python', ['compute_input.py']),
	data = [1,2,3,4,5,6,7,8,9],
	dataString = '';
	py.stdout.on('data', function(data){
	    dataString += data.toString();
	});
	//show data in terminal and send to html
	py.stdout.on('end', function(){
	    console.log('Sum of numbers=',dataString);
	    socket.emit("message", dataString);
	});
	py.stdin.write(JSON.stringify(data));
	py.stdin.end();
    });
});

server.listen(8082);

	 
	
